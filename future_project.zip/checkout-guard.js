(() => {
  const CHECKOUT_PATTERN = /결제하기|결제 진행|주문하기|구매하기|구매 진행|주문\/결제|place order|pay now|proceed to checkout/i;
  const NON_CHECKOUT_PATTERN = /취소|뒤로|계속 쇼핑|로그인|쿠폰|적용|삭제/i;
  const CONFIRM_PHRASE = "정말 구매합니다";
  const bypassedElements = new WeakSet();
  const bypassedForms = new WeakSet();
  const handledEvents = new WeakSet();
  const interceptingButtons = new WeakSet();
  let dialogHost;
  let dialogRoot;
  let activeAttempt;
  let activeButton;
  let cooldownTimer;
  let currentCooldown = null;

  function normalizeText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  async function requestCheckoutCooldown() {
    let lastError;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        const response = await chrome.runtime.sendMessage({ type: "GET_CHECKOUT_COOLDOWN" });
        if (!response?.ok) {
          throw new Error(response?.error || "확장 프로그램 서비스 워커가 대기 상태를 확인하지 못했습니다.");
        }
        return response.cooldown;
      } catch (error) {
        lastError = error;
        if (attempt === 0) {
          await new Promise((resolve) => setTimeout(resolve, 180));
        }
      }
    }
    throw lastError;
  }

  function formatRemaining(milliseconds) {
    const seconds = Math.max(0, Math.ceil(milliseconds / 1000));
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const rest = seconds % 60;
    if (hours > 0) return `${hours}시간 ${minutes}분`;
    if (minutes > 0) return `${minutes}분 ${rest}초`;
    return `${rest}초`;
  }

  function getCheckoutButton(event) {
    const path = typeof event.composedPath === "function" ? event.composedPath() : [event.target];
    const candidates = path.filter((node) =>
      node instanceof Element && node.matches("button, a, input[type='submit'], [role='button']")
    );
    for (const element of candidates) {
      if (dialogHost?.contains(element)) continue;
      if (isCheckoutElement(element)) return element;
    }
    return null;
  }

  function isCheckoutElement(element) {
    const text = normalizeText([
      element.innerText,
      element.textContent,
      element.getAttribute("aria-label"),
      element.getAttribute("value")
    ].join(" "));
    return CHECKOUT_PATTERN.test(text) && !NON_CHECKOUT_PATTERN.test(text);
  }

  function isExcludedText(text) {
    return /^(옵션|수량|삭제|찜하기|쿠폰|할인|배송비|로켓배송|내일 도착|만족했어요|한달구매|품절임박|무료배송)/.test(text);
  }

  function inferCategory(title) {
    const text = String(title || "").toLocaleLowerCase("ko-KR");
    const rules = [
      ["구독", /구독|멤버십|정기결제|넷플릭스|디즈니\+|유튜브 프리미엄|스포티파이/],
      ["디지털", /노트북|컴퓨터|키보드|마우스|모니터|휴대폰|스마트폰|이어폰|헤드폰|태블릿|카메라|전자/],
      ["패션", /신발|운동화|옷|의류|가방|코트|바지|원피스|패션/],
      ["뷰티", /화장품|스킨케어|향수|립스틱|크림|세럼|뷰티|샴푸/],
      ["생활", /가구|수납|청소|주방|침대|의자|책상|생활|행거|선반/],
      ["식품", /치킨|식품|간식|커피|음료|과자|식료품|밀키트/],
      ["취미", /게임|레고|악기|캠핑|운동|취미|책|도서|자전거/]
    ];
    return rules.find(([, pattern]) => pattern.test(text))?.[0] || "기타";
  }

  function titleTokens(title) {
    return String(title || "")
      .toLocaleLowerCase("ko-KR")
      .replace(/[^\p{L}\p{N}\s]/gu, " ")
      .split(/\s+/)
      .filter((token) => token.length >= 2 && !/^(정품|신제품|무료배송|로켓배송)$/.test(token));
  }

  async function findRegrettedSimilarItem(title) {
    const tokens = titleTokens(title);
    if (!tokens.length) return null;
    const stored = await chrome.storage.local.get("items");
    const items = Array.isArray(stored.items) ? stored.items : [];
    return items.find((item) => {
      if (!item.regretRecorded || item.regret !== true) return false;
      const previous = titleTokens(item.title);
      const shared = tokens.filter((token) => previous.includes(token)).length;
      return shared > 0 && shared / Math.max(tokens.length, previous.length) >= 0.4;
    }) || null;
  }

  function getAttemptDetails(button) {
    const cartRows = [...document.querySelectorAll(".cart-deal-item")];
    if (location.hostname === "shopping.naver.com" || location.hostname === "buy.11st.co.kr") {
      const rows = new Set(cartRows);
      for (const checkbox of document.querySelectorAll('input[type="checkbox"], [role="checkbox"]')) {
        const identity = `${checkbox.id || ""} ${checkbox.getAttribute("name") || ""}`;
        const labelText = normalizeText(checkbox.closest("label")?.textContent);
        if (/all|전체/i.test(identity) || /^(전체\s*선택|모두\s*선택)$/.test(labelText)) continue;
        const isChecked = checkbox instanceof HTMLInputElement
          ? checkbox.checked
          : checkbox.getAttribute("aria-checked") === "true";
        if (!isChecked) continue;
        let row = checkbox.parentElement;
        for (let depth = 0; row && depth < 24; depth += 1, row = row.parentElement) {
          const hasImage = row.querySelector("img");
          const hasPrice = row.querySelector("[class*='price'], [class*='amount']");
          const checkableCount = row.querySelectorAll('input[type="checkbox"], [role="checkbox"]').length;
          if (hasImage && hasPrice && checkableCount === 1) {
            rows.add(row);
            break;
          }
        }
      }
      cartRows.splice(0, cartRows.length, ...rows);
    }
    const selectedRows = cartRows.filter((row) => {
      const checkbox = row.querySelector('input[type="checkbox"], [role="checkbox"]');
      return checkbox instanceof HTMLInputElement
        ? checkbox.checked
        : checkbox?.getAttribute("aria-checked") === "true";
    });
    const row = selectedRows[0];
    const titleNode = row?.querySelector(".product-name-part, .name, [class*='product-name'], [class*='productName']")
      || [...(row?.querySelectorAll("a[href]") || [])]
        .filter((link) => /\/(?:vp\/)?products?(?:\/|\.tmall)|prdNo=/i.test(link.href))
        .find((link) => normalizeText(link.textContent).length >= 6);
    const title = normalizeText(titleNode?.textContent)
      || normalizeText(document.querySelector("h1")?.textContent)
      || normalizeText(document.title).replace(/\s*[|｜-]\s*(?:쿠팡|네이버쇼핑|네이버페이|11번가).*$/i, "");
    const priceText = row?.querySelector(".unit-total-price, .total-price, [class*='price'], [class*='amount']")?.textContent
      || document.querySelector("[class*='total-price'], [class*='final-price'], [class*='price'], [class*='amount']")?.textContent
      || "";
    const priceMatches = [...priceText.matchAll(/(?:₩\s*([\d,]+)|([\d,]+)\s*(?:원|KRW))/gi)];
    const price = Number((priceMatches.at(-1)?.[1] || priceMatches.at(-1)?.[2] || "").replace(/[^\d]/g, ""));
    return {
      title: isExcludedText(title) ? "" : title.slice(0, 120),
      price: Number.isSafeInteger(price) && price > 0 ? price : 0,
      category: inferCategory(title),
      button
    };
  }

  function makeElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  function ensureDialog() {
    if (dialogHost?.isConnected && dialogRoot) return;
    dialogHost = document.createElement("div");
    dialogHost.id = "huthnal-checkout-intervention";
    dialogRoot = dialogHost.attachShadow({ mode: "closed" });

    const style = document.createElement("style");
    style.textContent = `
      :host { all: initial; }
      * { box-sizing: border-box; }
      .scrim { position: fixed; inset: 0; z-index: 2147483647; display: grid; place-items: center; padding: 18px; background: rgba(18, 42, 68, .38); font: 14px/1.5 "Segoe UI", "Malgun Gothic", sans-serif; color: #1e3347; }
      .dialog { width: min(480px, 100%); max-height: min(740px, calc(100vh - 36px)); overflow: auto; border: 1px solid #d8e8f6; border-radius: 18px; background: #f8fbfe; box-shadow: 0 18px 60px rgba(20, 70, 120, .20); }
      header { padding: 21px 24px 18px; background: linear-gradient(145deg, #328ad6 0%, #1f72b8 100%); color: #fff; }
      .eyebrow { margin: 0 0 5px; color: #c4e3fc; font-size: 11px; letter-spacing: .08em; }
      h2 { margin: 0; font-size: 21px; letter-spacing: -.03em; }
      .subtitle { margin: 7px 0 0; color: #e1f0fc; font-size: 12px; }
      .content { padding: 20px 24px 24px; }
      .product { display: flex; justify-content: space-between; gap: 12px; margin-bottom: 17px; padding: 12px 14px; border: 1px solid #d8e8f6; border-radius: 11px; background: #fff; box-shadow: 0 1px 3px rgb(40 120 180 / 5%); }
      .product strong { overflow-wrap: anywhere; }
      .product span { flex: 0 0 auto; color: #1773ba; font-weight: 700; }
      label { display: block; margin: 0 0 12px; color: #4a6782; font-size: 12px; font-weight: 650; }
      input[type="text"], input[type="number"] { width: 100%; min-height: 40px; margin-top: 5px; padding: 9px 11px; border: 1px solid #d4e5f4; border-radius: 8px; background: #fff; color: #1e3347; font: inherit; }
      .question { padding: 12px 0; border-top: 1px solid #dbe8f4; }
      .question p { margin: 0 0 9px; font-size: 13px; font-weight: 650; }
      .choices { display: flex; gap: 8px; }
      .choices label { display: flex; flex: 1; align-items: center; gap: 7px; margin: 0; padding: 9px 10px; border: 1px solid #d8e8f6; border-radius: 8px; background: #fff; cursor: pointer; }
      .choices input { accent-color: #2b8ed9; }
      .assessment { margin: 14px 0; padding: 13px 14px; border-left: 3px solid #b8d2e8; border-radius: 0 8px 8px 0; background: #edf5fc; transition: color 180ms ease, background-color 180ms ease, border-color 180ms ease; }
      .assessment.risk-low { border-color: #39805a; background: #eaf3ec; color: #24553a; }
      .assessment.risk-medium { border-color: #b58b27; background: #f7f1dd; color: #725714; }
      .assessment.risk-high { border-color: #b34b40; background: #f7e9e6; color: #7f3028; }
      .assessment strong { display: block; margin-bottom: 3px; }
      .assessment p { margin: 0; color: #5f6d64; font-size: 12px; }
      .assessment.risk-low p { color: #24553a; }
      .assessment.risk-medium p { color: #725714; }
      .assessment.risk-high p { color: #7f3028; }
      .timer { margin: 14px 0; padding: 18px; border-radius: 12px; background: linear-gradient(145deg, #328ad6 0%, #1f72b8 100%); color: #fff; text-align: center; box-shadow: 0 4px 14px rgb(30 115 186 / 22%); }
      .timer strong { display: block; font-size: 32px; letter-spacing: .02em; font-variant-numeric: tabular-nums; }
      .timer p { margin: 4px 0 0; color: #e1f0fc; font-size: 12px; }
      .hint { margin: 10px 0 0; color: #64829d; font-size: 12px; }
      .actions { display: flex; gap: 9px; margin-top: 17px; }
      button { min-height: 42px; padding: 9px 14px; border: 1px solid #d4e5f4; border-radius: 9px; background: #fff; color: #1768a3; font: 700 12px "Segoe UI", "Malgun Gothic", sans-serif; cursor: pointer; }
      button.primary { flex: 1; border-color: #278dd9; background: #278dd9; box-shadow: 0 2px 8px rgb(39 141 217 / 25%); color: #fff; }
      button.primary:hover { background: #1b7bc3; }
      button:focus-visible, input:focus-visible { outline: 3px solid #7cbbe8; outline-offset: 2px; }
      .error { min-height: 16px; margin: 7px 0 0; color: #b5493b; font-size: 12px; }
      .error-message { margin: 0; color: #4a6782; font-size: 13px; line-height: 1.7; white-space: pre-line; overflow-wrap: anywhere; }
    `;
    dialogRoot.append(style);
    document.documentElement.append(dialogHost);
  }

  function showDialog() {
    if (dialogHost?.isConnected) return;
    ensureDialog();
    renderQuestionnaire();
  }

  function renderErrorDialog(message) {
    ensureDialog();
    const scrim = makeElement("div", "scrim");
    const dialog = makeElement("section", "dialog");
    dialog.setAttribute("role", "alertdialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.setAttribute("aria-label", "결제 개입 오류");
    const header = document.createElement("header");
    header.append(
      makeElement("p", "eyebrow", "HUTHNAL NOTICE"),
      makeElement("h2", "", "결제를 진행하지 않았어요"),
      makeElement("p", "subtitle", "문제를 확인한 뒤 다시 시도해 주세요.")
    );
    const content = makeElement("div", "content");
    const detail = makeElement("p", "error-message", message);
    const actions = makeElement("div", "actions");
    const close = makeElement("button", "primary", "확인");
    close.type = "button";
    close.addEventListener("click", closeDialog);
    actions.append(close);
    content.append(detail, actions);
    dialog.append(header, content);
    scrim.append(dialog);
    dialogRoot.replaceChildren(dialogRoot.querySelector("style"), scrim);
    close.focus();
  }

  function buildQuestions() {
    return [
      { id: "similar", text: "이미 비슷한 물건을 가지고 있나요?", risk: "yes" },
      { id: "month", text: "한 달 뒤에도 자주 사용할 것 같나요?", risk: "no" },
      { id: "fullPrice", text: "정가여도 이 물건을 사고 싶나요?", risk: "no" },
      { id: "planned", text: "오늘 사기로 미리 계획한 물건인가요?", risk: "no" }
    ];
  }

  function calculateRisk(answers) {
    return buildQuestions().reduce((total, question) =>
      total + (answers[question.id] === question.risk ? 2 : 0), 0
    );
  }

  function getRiskBand(score) {
    if (score >= 6) return { key: "high", className: "risk-high", label: "높음", detail: "충동 구매 위험이 높아요. 대기 후에도 구매하려면 문구 확인이 필요합니다." };
    if (score >= 3) return { key: "medium", className: "risk-medium", label: "보통", detail: "잠시 멈춰 필요성을 한 번 더 살펴보면 좋겠습니다." };
    return { key: "low", className: "risk-low", label: "낮음", detail: "구매 계획과 사용 목적이 비교적 분명해 보여요." };
  }

  function renderQuestionnaire() {
    const scrim = makeElement("div", "scrim");
    scrim.addEventListener("click", (event) => {
      if (event.target === scrim) closeDialog();
    });
    const dialog = makeElement("section", "dialog");
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.setAttribute("aria-labelledby", "huthnal-title");
    const header = document.createElement("header");
    header.append(
      makeElement("p", "eyebrow", "CHECK IN WITH YOURSELF"),
      makeElement("h2", "", "결정하기 전에 잠시 멈춰요"),
      makeElement("p", "subtitle", "결제는 잠시 보류됩니다. 답변은 이 브라우저에만 저장돼요.")
    );
    const content = makeElement("div", "content");
    const product = makeElement("div", "product");
    const title = document.createElement("strong");
    title.textContent = activeAttempt.title || "구매하려는 상품";
    const price = document.createElement("span");
    price.textContent = activeAttempt.price ? `${activeAttempt.price.toLocaleString("ko-KR")}원` : "가격 직접 입력";
    product.append(title, price);
    content.append(product);
    findRegrettedSimilarItem(activeAttempt.title).then((previous) => {
      if (!previous || !dialog.isConnected) return;
      const warning = makeElement("div", "assessment");
      warning.append(
        makeElement("strong", "", "지난번 비슷한 물건은 후회했다고 기록했어요."),
        makeElement("p", "", `“${previous.title}” 구매 후 사용 만족도가 낮았어요.`)
      );
      product.after(warning);
    }).catch((error) => {
      console.error("비슷한 구매 후회 기록을 확인하지 못했습니다.", error);
    });

    const titleLabel = makeElement("label", "", "상품명");
    const titleInput = document.createElement("input");
    titleInput.type = "text";
    titleInput.maxLength = 120;
    titleInput.value = activeAttempt.title;
    titleInput.placeholder = "상품명을 확인하거나 입력해 주세요";
    titleInput.dataset.field = "title";
    titleLabel.append(titleInput);
    const priceLabel = makeElement("label", "", "가격 (원)");
    const priceInput = document.createElement("input");
    priceInput.type = "number";
    priceInput.min = "0";
    priceInput.step = "1";
    priceInput.value = activeAttempt.price || "";
    priceInput.placeholder = "확인 가능한 가격을 입력해 주세요";
    priceInput.dataset.field = "price";
    priceLabel.append(priceInput);
    content.append(titleLabel, priceLabel);

    const answers = {};
    const questionElements = [];
    buildQuestions().forEach((question, index) => {
      const questionElement = makeElement("div", "question");
      const prompt = makeElement("p", "", `${index + 1}. ${question.text}`);
      const choices = makeElement("div", "choices");
      ["yes", "no"].forEach((answer) => {
        const choiceLabel = document.createElement("label");
        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = question.id;
        radio.value = answer;
        radio.addEventListener("change", () => {
          answers[question.id] = answer;
          updateAssessment();
        });
        choiceLabel.append(radio, document.createTextNode(answer === "yes" ? "네" : "아니요"));
        choices.append(choiceLabel);
      });
      questionElement.append(prompt, choices);
      questionElements.push(questionElement);
    });
    content.append(...questionElements);
    const assessment = makeElement("div", "assessment");
    const assessmentTitle = makeElement("strong", "", "답변을 선택해 주세요");
    const assessmentDetail = makeElement("p", "", "네 가지 질문에 답하면 구매 위험도를 보여드려요.");
    assessment.append(assessmentTitle, assessmentDetail);
    content.append(assessment);
    const error = makeElement("p", "error");
    error.setAttribute("role", "status");
    content.append(error);
    const actions = makeElement("div", "actions");
    const cancel = makeElement("button", "", "결제 취소");
    cancel.type = "button";
    cancel.addEventListener("click", closeDialog);
    const start = makeElement("button", "primary", "답변하고 대기 시작");
    start.type = "button";
    start.addEventListener("click", async () => {
      if (Object.keys(answers).length !== 4) {
        error.textContent = "네 질문에 모두 답해 주세요.";
        return;
      }
      const titleValue = titleInput.value.trim();
      const priceValue = Number(priceInput.value);
      if (!titleValue || !priceInput.value || !Number.isSafeInteger(priceValue) || priceValue < 1) {
        error.textContent = "상품명과 1원 이상의 가격을 입력해 주세요.";
        return;
      }
      activeAttempt.title = titleValue;
      activeAttempt.price = priceValue;
      activeAttempt.answers = answers;
      activeAttempt.riskScore = calculateRisk(answers);
      const band = getRiskBand(activeAttempt.riskScore);
      start.disabled = true;
      try {
        const response = await chrome.runtime.sendMessage({
          type: "BEGIN_CHECKOUT_COOLDOWN",
          title: titleValue,
          price: priceValue,
          riskScore: activeAttempt.riskScore,
          riskLabel: band.label,
          category: inferCategory(titleValue)
        });
        if (!response?.ok) throw new Error(response?.error || "대기 시간을 설정하지 못했습니다.");
        currentCooldown = response.cooldown;
        renderCooldown(band);
      } catch (requestError) {
        console.error("결제 대기 시간을 시작하지 못했습니다.", requestError);
        error.textContent = "대기를 시작하지 못했어요. 확장 프로그램 설정을 확인해 주세요.";
        start.disabled = false;
      }
    });
    actions.append(cancel, start);
    content.append(actions);
    dialog.append(header, content);
    scrim.append(dialog);
    dialogRoot.replaceChildren(dialogRoot.querySelector("style"), scrim);
    titleInput.focus();
    activeAttempt.answers = answers;
    activeAttempt.updateAssessment = () => {
      if (Object.keys(answers).length !== 4) return;
      const band = getRiskBand(calculateRisk(answers));
      assessment.classList.remove("risk-low", "risk-medium", "risk-high");
      assessment.classList.add(band.className);
      assessmentTitle.textContent = `충동구매 위험도: ${band.label}`;
      assessmentDetail.textContent = band.detail;
    };

    function updateAssessment() {
      activeAttempt.updateAssessment();
    }
  }

  function renderCooldown(band) {
    ensureDialog();
    const scrim = makeElement("div", "scrim");
    const dialog = makeElement("section", "dialog");
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    const header = document.createElement("header");
    header.append(
      makeElement("p", "eyebrow", "A LITTLE SPACE TO THINK"),
      makeElement("h2", "", "결제를 잠시 보류했어요"),
      makeElement("p", "subtitle", `충동구매 위험도 ${band.label}${currentCooldown.nightModeApplied ? " · 취약 시간대 보호 적용" : ""} · ${activeAttempt?.title || currentCooldown.title}`)
    );
    const content = makeElement("div", "content");
    const assessment = makeElement("div", "assessment");
    assessment.classList.add(band.className);
    assessment.append(
      makeElement("strong", "", `충동구매 위험도: ${band.label}`),
      makeElement("p", "", band.detail)
    );
    const timer = makeElement("div", "timer");
    const remaining = makeElement("strong", "", "");
    const timerHint = makeElement("p", "", "");
    timer.append(remaining, timerHint);
    const delaySeconds = Math.round((currentCooldown.expiresAt - currentCooldown.startedAt) / 1000);
    const delayLabel = formatRemaining(delaySeconds * 1000);
    timerHint.textContent = `${delayLabel} 뒤 알림을 드려요. 결제는 자동으로 진행되지 않습니다.`;
    const hint = makeElement("p", "hint", "시간이 끝나도 이 탭에서 결제 버튼을 다시 눌러야 진행됩니다.");
    const error = makeElement("p", "error");
    const actions = makeElement("div", "actions");
    const cancel = makeElement("button", "", "결제 취소");
    cancel.type = "button";
    cancel.addEventListener("click", async () => {
      if (currentCooldown && Date.now() >= currentCooldown.expiresAt) {
        closeDialog();
        return;
      }
      try {
        const response = await chrome.runtime.sendMessage({ type: "CANCEL_CHECKOUT_COOLDOWN" });
        if (!response?.ok) throw new Error(response?.error || "결제 포기 기록을 저장하지 못했습니다.");
        currentCooldown = null;
        closeDialog();
      } catch (cancelError) {
        console.error("결제 대기를 취소하지 못했습니다.", cancelError);
        error.textContent = "취소 기록을 저장하지 못했습니다. 다시 시도해 주세요.";
      }
    });
    actions.append(cancel);
    content.append(assessment, timer, hint, error, actions);
    dialog.append(header, content);
    scrim.append(dialog);
    dialogRoot.replaceChildren(dialogRoot.querySelector("style"), scrim);
    clearInterval(cooldownTimer);

    let notified = false;
    function updateTimer() {
      const milliseconds = currentCooldown.expiresAt - Date.now();
      remaining.textContent = formatRemaining(milliseconds);
      if (milliseconds <= 0) {
        clearInterval(cooldownTimer);
        timerHint.textContent = "대기 시간이 끝났어요. 다시 사고 싶다면 결제 버튼을 눌러 주세요.";
        hint.textContent = "대기 시간이 끝났습니다. 구매 여부를 다시 결정할 수 있어요.";
        cancel.textContent = "대기 화면 닫기";
        if (!notified) {
          notified = true;
          chrome.runtime.sendMessage({ type: "CHECKOUT_COOLDOWN_EXPIRED" }).catch((error) => {
            console.error("대기 완료 알림을 보내지 못했습니다.", error);
          });
        }
      }
    }
    updateTimer();
    cooldownTimer = setInterval(updateTimer, 1000);
  }

  function renderReadyDialog(cooldown) {
    ensureDialog();
    currentCooldown = cooldown;
    activeAttempt = {
      title: cooldown.title,
      price: cooldown.price,
      riskScore: cooldown.riskScore,
      button: activeButton
    };
    const band = getRiskBand(cooldown.riskScore);
    const scrim = makeElement("div", "scrim");
    const dialog = makeElement("section", "dialog");
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    const header = document.createElement("header");
    header.append(
      makeElement("p", "eyebrow", "THE PAUSE IS OVER"),
      makeElement("h2", "", "다시 결정할 시간이에요"),
      makeElement("p", "subtitle", `충동구매 위험도 ${band.label}${cooldown.nightModeApplied ? " · 취약 시간대 보호 적용" : ""}`)
    );
    const content = makeElement("div", "content");
    const message = makeElement("p", "", `${cooldown.title} 구매 대기 시간이 끝났습니다. 결제를 자동으로 진행하지 않았어요.`);
    const assessment = makeElement("div", "assessment");
    assessment.classList.add(band.className);
    assessment.append(
      makeElement("strong", "", `충동구매 위험도: ${band.label}`),
      makeElement("p", "", band.detail)
    );
    const error = makeElement("p", "error");
    const actions = makeElement("div", "actions");
    const cancel = makeElement("button", "", "구매하지 않기");
    cancel.type = "button";
    cancel.addEventListener("click", async () => {
      try {
        const response = await chrome.runtime.sendMessage({ type: "CANCEL_CHECKOUT_COOLDOWN" });
        if (!response?.ok) throw new Error(response?.error || "결제 포기 기록을 저장하지 못했습니다.");
        currentCooldown = null;
        closeDialog();
      } catch (cancelError) {
        console.error("결제 포기 기록을 저장하지 못했습니다.", cancelError);
        error.textContent = "포기 기록을 저장하지 못했습니다. 다시 시도해 주세요.";
      }
    });
    actions.append(cancel);

    if (cooldown.riskScore >= 6 || cooldown.requireTypedConfirmation) {
      const label = makeElement("label", "", `계속하려면 “${CONFIRM_PHRASE}”를 입력해 주세요.`);
      const input = document.createElement("input");
      input.type = "text";
      input.autocomplete = "off";
      input.placeholder = CONFIRM_PHRASE;
      input.dataset.confirm = "true";
      label.append(input);
      content.append(label);
    } else {
      content.append(makeElement("p", "hint", band.detail));
    }

    const proceed = makeElement("button", "primary", "결제 버튼으로 돌아가기");
    proceed.type = "button";
    proceed.addEventListener("click", async () => {
      const confirmInput = dialogRoot.querySelector("[data-confirm]");
      if (confirmInput && confirmInput.value !== CONFIRM_PHRASE) {
        error.textContent = `계속하려면 “${CONFIRM_PHRASE}”를 정확히 입력해 주세요.`;
        return;
      }
      const button = activeButton;
      if (!(button instanceof HTMLElement) || !button.isConnected) {
        error.textContent = "결제 버튼을 찾지 못했어요. 페이지에서 다시 시도해 주세요.";
        return;
      }
      proceed.disabled = true;
      try {
        const purchaseResult = await chrome.runtime.sendMessage({
          type: "RECORD_CHECKOUT_PURCHASE",
          title: cooldown.title,
          price: cooldown.price,
          riskScore: cooldown.riskScore,
          category: inferCategory(cooldown.title)
        });
        if (!purchaseResult?.ok) throw new Error(purchaseResult?.error || "구매 후 확인 기록을 저장하지 못했습니다.");
        const clearResult = await chrome.runtime.sendMessage({ type: "CLEAR_CHECKOUT_COOLDOWN" });
        if (!clearResult?.ok) throw new Error(clearResult?.error || "대기 상태를 정리하지 못했습니다.");
        closeDialog();
        bypassedElements.add(button);
        if (button.form) bypassedForms.add(button.form);
        button.click();
      } catch (requestError) {
        console.error("결제 재개 상태를 정리하지 못했습니다.", requestError);
        error.textContent = "결제를 재개하지 못했어요. 페이지에서 다시 시도해 주세요.";
        proceed.disabled = false;
      }
    });
    actions.append(proceed);
    content.append(assessment, message, error, actions);
    dialog.append(header, content);
    scrim.append(dialog);
    dialogRoot.replaceChildren(dialogRoot.querySelector("style"), scrim);
  }

  function closeDialog() {
    clearInterval(cooldownTimer);
    cooldownTimer = undefined;
    dialogHost?.remove();
    dialogHost = undefined;
    dialogRoot = undefined;
    activeAttempt = undefined;
  }

  async function interceptCheckout(event, button = getCheckoutButton(event)) {
    if (!button) return;
    if (handledEvents.has(event)) return;
    handledEvents.add(event);
    if (bypassedElements.has(button)) {
      bypassedElements.delete(button);
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
    if (interceptingButtons.has(button)) return;
    interceptingButtons.add(button);
    activeButton = button;
    try {
      const cooldown = await requestCheckoutCooldown();
      if (cooldown && cooldown.expiresAt > Date.now()) {
        currentCooldown = cooldown;
        activeAttempt = { title: cooldown.title, price: cooldown.price, button };
        renderCooldown(getRiskBand(cooldown.riskScore));
      } else if (cooldown) {
        renderReadyDialog(cooldown);
      } else {
        activeAttempt = getAttemptDetails(button);
        showDialog();
      }
    } catch (error) {
      console.error("결제 버튼 개입을 초기화하지 못했습니다.", error);
      const detail = error instanceof Error ? error.message : String(error);
      renderErrorDialog(
        `훗날이 결제 대기 상태를 확인하지 못해 결제를 진행하지 않았습니다.\n\n원인: ${detail}\n\n확장 프로그램 관리 화면에서 훗날을 새로고침하고, 쇼핑몰 페이지도 새로고침한 뒤 다시 시도해 주세요.`
      );
    } finally {
      interceptingButtons.delete(button);
    }
  }

  document.addEventListener("click", (event) => {
    void interceptCheckout(event);
  }, true);
  document.addEventListener("submit", (event) => {
    if (event.target instanceof HTMLFormElement && bypassedForms.has(event.target)) {
      bypassedForms.delete(event.target);
      return;
    }
    const submitter = event.submitter;
    const button = submitter instanceof Element && isCheckoutElement(submitter)
      ? submitter
      : event.target instanceof HTMLFormElement
        ? [...event.target.querySelectorAll("button[type='submit'], input[type='submit']")]
            .find(isCheckoutElement)
        : null;
    void interceptCheckout(event, button);
  }, true);
})();
