const COOLDOWN_PREFIX = "checkout-cooldown:";
const ALARM_PREFIX = "checkout-cooldown-";
const BUDGET_REFRESH_ALARM = "budget-month-refresh";

function cooldownKey(tabId) {
  return `${COOLDOWN_PREFIX}${tabId}`;
}

function alarmName(tabId) {
  return `${ALARM_PREFIX}${tabId}`;
}

async function beginCooldown(message, tabId) {
  if (typeof tabId !== "number") {
    throw new Error("결제 대기 시간에는 활성 탭이 필요합니다.");
  }
  const settingsStored = await chrome.storage.local.get("settings");
  const settings = settingsStored.settings || {};
  const currentHour = new Date().getHours();
  const startHour = Number(settings.nightStartHour);
  const endHour = Number(settings.nightEndHour);
  const inNightRange = settings.nightModeEnabled === true
    && Number.isInteger(startHour)
    && Number.isInteger(endHour)
    && (startHour < endHour
      ? currentHour >= startHour && currentHour < endHour
      : startHour > endHour && (currentHour >= startHour || currentHour < endHour));
  const riskScore = Math.min(8, Math.max(0, Math.floor(Number(message.riskScore) || 0)));
  const riskLevel = riskScore >= 6 ? "high" : riskScore >= 3 ? "medium" : "low";
  const riskDelays = settings.riskDelaySeconds && typeof settings.riskDelaySeconds === "object"
    ? settings.riskDelaySeconds
    : {};
  const legacyDelay = Number(settings.delaySeconds);
  const configuredDelay = Number(riskDelays[riskLevel]);
  const baseDelay = Math.min(86400, Math.max(10, Math.floor(
    Number.isFinite(configuredDelay) ? configuredDelay : legacyDelay || 60
  )));
  const nightDelay = inNightRange ? Math.max(1, Number(settings.nightDelayMinutes) || 30) * 60 : 0;
  const delaySeconds = Math.min(86400, baseDelay + nightDelay);
  const cooldown = {
    tabId,
    title: String(message.title || "구매하려는 상품").slice(0, 160),
    price: Number.isSafeInteger(message.price) && message.price > 0 ? message.price : 0,
    riskScore,
    riskLevel,
    riskLabel: String(message.riskLabel || "보통"),
    category: String(message.category || "기타"),
    nightModeApplied: inNightRange,
    requireTypedConfirmation: inNightRange && settings.nightRequireConfirmation === true,
    startedAt: Date.now(),
    expiresAt: Date.now() + delaySeconds * 1000
  };
  await chrome.storage.local.set({ [cooldownKey(tabId)]: cooldown });
  await chrome.alarms.create(alarmName(tabId), { when: cooldown.expiresAt });
  await appendActivity({
    type: "checkout_attempt",
    at: cooldown.startedAt,
    title: cooldown.title,
    price: cooldown.price,
    category: cooldown.category,
    riskScore: cooldown.riskScore,
    hour: new Date(cooldown.startedAt).getHours(),
    dayOfMonth: new Date(cooldown.startedAt).getDate()
  });
  return cooldown;
}

function formatCurrency(amount) {
  return new Intl.NumberFormat("ko-KR", {
    style: "currency",
    currency: "KRW",
    maximumFractionDigits: 0
  }).format(amount);
}

async function updateBudgetBadge() {
  const stored = await chrome.storage.local.get(["settings", "activityEvents"]);
  const settings = stored.settings || {};
  const monthlyBudget = Number(settings.monthlyBudget) || 0;
  if (monthlyBudget <= 0) {
    await chrome.action.setBadgeText({ text: "" });
    await chrome.action.setTitle({ title: "훗날 · 오늘의 선택이 만드는 내일" });
    await chrome.alarms.clear(BUDGET_REFRESH_ALARM);
    return;
  }

  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
  const events = Array.isArray(stored.activityEvents) ? stored.activityEvents : [];
  const spent = events
    .filter((event) => ["purchase", "purchase_intent"].includes(event.type)
      && Number.isFinite(event.at) && event.at >= monthStart && event.at <= now.getTime())
    .reduce((total, event) => total + (Number.isSafeInteger(event.price) && event.price > 0 ? event.price : 0), 0);
  const remaining = monthlyBudget - spent;
  let badgeText;
  if (remaining < 0) {
    badgeText = "초과";
  } else if (remaining >= 10000000) {
    badgeText = "999+";
  } else if (remaining >= 10000) {
    badgeText = `${Math.floor(remaining / 10000)}만`;
  } else if (remaining >= 1000) {
    badgeText = `${Math.floor(remaining / 1000)}천`;
  } else {
    badgeText = String(remaining);
  }
  await chrome.action.setBadgeText({ text: badgeText });
  await chrome.action.setBadgeBackgroundColor({ color: remaining < 0 ? "#ba4738" : "#278dd9" });
  await chrome.action.setTitle({
    title: `훗날 · 이번 달 남은 쇼핑 예산 ${formatCurrency(remaining)} · 구매 결정 기준, 결제 확인 미연동`
  });
  await chrome.alarms.create(BUDGET_REFRESH_ALARM, {
    when: new Date(now.getFullYear(), now.getMonth() + 1, 1, 0, 5).getTime()
  });
}

async function appendActivity(event) {
  const stored = await chrome.storage.local.get("activityEvents");
  const events = Array.isArray(stored.activityEvents) ? stored.activityEvents : [];
  await chrome.storage.local.set({
    activityEvents: [...events, { id: crypto.randomUUID(), ...event }]
  });
}

async function recordCheckoutPurchase(message, tabId) {
  const now = Date.now();
  const itemId = crypto.randomUUID();
  const item = {
    id: itemId,
    title: String(message.title || "구매한 상품").slice(0, 120),
    price: Number.isSafeInteger(message.price) && message.price > 0 ? message.price : 0,
    category: String(message.category || "기타"),
    sourceKey: `checkout:${tabId}:${now}`,
    addedAt: now,
    resolvedAt: now,
    followupDueAt: now + 14 * 24 * 60 * 60 * 1000,
    status: "checkout_pending",
    recurring: false,
    priceHistory: [{ at: now, price: Number(message.price) || 0 }]
  };
  const stored = await chrome.storage.local.get("items");
  const items = Array.isArray(stored.items) ? stored.items : [];
  const activityStored = await chrome.storage.local.get("activityEvents");
  const events = Array.isArray(activityStored.activityEvents) ? activityStored.activityEvents : [];
  await chrome.storage.local.set({
    items: [...items, item],
    activityEvents: [...events, {
      id: crypto.randomUUID(),
      type: "purchase_intent",
      itemId,
      at: now,
      title: item.title,
      price: item.price,
      category: item.category,
      riskScore: Number(message.riskScore) || 0,
      hour: new Date(now).getHours(),
      dayOfMonth: new Date(now).getDate()
    }]
  });
}

async function recordCheckoutCancellation(tabId) {
  if (typeof tabId !== "number") return;
  const key = cooldownKey(tabId);
  const stored = await chrome.storage.local.get([key, "activityEvents"]);
  const cooldown = stored[key];
  if (cooldown) {
    const events = Array.isArray(stored.activityEvents) ? stored.activityEvents : [];
    const now = Date.now();
    await chrome.storage.local.set({
      activityEvents: [...events, {
        id: crypto.randomUUID(),
        type: "resisted",
        at: now,
        title: cooldown.title,
        price: cooldown.price,
        category: cooldown.category || "기타",
        riskScore: cooldown.riskScore,
        hour: new Date(now).getHours(),
        dayOfMonth: new Date(now).getDate()
      }]
    });
  }
  await clearCooldown(tabId);
}

async function clearCooldown(tabId) {
  if (typeof tabId !== "number") return;
  await chrome.alarms.clear(alarmName(tabId));
  await chrome.storage.local.remove(cooldownKey(tabId));
}

async function getCooldown(tabId) {
  if (!Number.isInteger(tabId)) {
    throw new Error("결제 페이지 탭 정보를 받지 못했습니다. 쇼핑몰 페이지를 새로고침해 주세요.");
  }
  const key = cooldownKey(tabId);
  const stored = await chrome.storage.local.get(key);
  return stored[key] || null;
}

async function notifyCooldownReady(tabId) {
  if (typeof tabId !== "number") return;
  const key = cooldownKey(tabId);
  const stored = await chrome.storage.local.get(key);
  const cooldown = stored[key];
  if (!cooldown || cooldown.expiresAt > Date.now() || cooldown.notifiedAt) return;
  await chrome.storage.local.set({ [key]: { ...cooldown, notifiedAt: Date.now() } });
  await chrome.notifications.create(`checkout-ready-${tabId}`, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: "훗날 · 다시 생각해 볼 시간",
    message: `${cooldown.title} 구매를 다시 검토할 수 있어요. 필요하다면 탭에서 직접 다시 진행해 주세요.`,
    priority: 0
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab?.id;
  if (message?.type === "BEGIN_CHECKOUT_COOLDOWN") {
    beginCooldown(message, tabId)
      .then((cooldown) => sendResponse({ ok: true, cooldown }))
      .catch((error) => {
        console.error("결제 대기 시간을 설정하지 못했습니다.", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message?.type === "GET_CHECKOUT_COOLDOWN") {
    getCooldown(tabId)
      .then((cooldown) => sendResponse({ ok: true, cooldown }))
      .catch((error) => {
        console.error("결제 대기 상태를 불러오지 못했습니다.", error);
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : String(error)
        });
      });
    return true;
  }

  if (message?.type === "CLEAR_CHECKOUT_COOLDOWN") {
    clearCooldown(tabId)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.error("결제 대기 상태를 지우지 못했습니다.", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message?.type === "CANCEL_CHECKOUT_COOLDOWN") {
    recordCheckoutCancellation(tabId)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.error("결제 포기 기록을 저장하지 못했습니다.", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message?.type === "CHECKOUT_COOLDOWN_EXPIRED") {
    notifyCooldownReady(tabId)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.error("대기 완료 알림을 표시하지 못했습니다.", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message?.type === "RECORD_CHECKOUT_PURCHASE") {
    recordCheckoutPurchase(message, tabId)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.error("구매 후 확인 기록을 저장하지 못했습니다.", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === BUDGET_REFRESH_ALARM) {
    try {
      await updateBudgetBadge();
    } catch (error) {
      console.error("이번 달 쇼핑 예산 배지를 갱신하지 못했습니다.", error);
    }
    return;
  }
  if (!alarm.name.startsWith(ALARM_PREFIX)) return;
  const tabId = Number(alarm.name.slice(ALARM_PREFIX.length));
  const key = cooldownKey(tabId);
  const stored = await chrome.storage.local.get(key);
  const cooldown = stored[key];
  if (!cooldown) return;

  if (cooldown.expiresAt > Date.now()) {
    await chrome.alarms.create(alarm.name, { when: cooldown.expiresAt });
    return;
  }

  await notifyCooldownReady(tabId);
});

chrome.tabs.onRemoved.addListener((tabId) => {
  clearCooldown(tabId).catch((error) => {
    console.error("닫은 탭의 결제 대기 정보를 정리하지 못했습니다.", error);
  });
});

chrome.notifications.onClicked.addListener(async (notificationId) => {
  if (!notificationId.startsWith("checkout-ready-")) return;
  const tabId = Number(notificationId.slice("checkout-ready-".length));
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.id !== undefined) {
      await chrome.tabs.update(tab.id, { active: true });
      if (tab.windowId !== undefined) await chrome.windows.update(tab.windowId, { focused: true });
    }
  } catch (error) {
    console.error("결제 대기 알림의 탭을 열지 못했습니다.", error);
  }
});

chrome.runtime.onStartup.addListener(async () => {
  updateBudgetBadge().catch((error) => {
    console.error("쇼핑 예산 배지를 초기화하지 못했습니다.", error);
  });
  const stored = await chrome.storage.local.get(null);
  for (const [key, cooldown] of Object.entries(stored)) {
    if (!key.startsWith(COOLDOWN_PREFIX) || !cooldown?.expiresAt) continue;
    const tabId = cooldown.tabId;
    if (cooldown.expiresAt <= Date.now()) {
      await chrome.alarms.create(alarmName(tabId), { when: Date.now() + 1000 });
    } else {
      await chrome.alarms.create(alarmName(tabId), { when: cooldown.expiresAt });
    }
  }
});

chrome.runtime.onInstalled.addListener(() => {
  updateBudgetBadge().catch((error) => {
    console.error("쇼핑 예산 배지를 초기화하지 못했습니다.", error);
  });
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local" || (!changes.settings && !changes.activityEvents)) return;
  updateBudgetBadge().catch((error) => {
    console.error("쇼핑 예산 배지를 갱신하지 못했습니다.", error);
  });
});
