(() => {
  const app = globalThis.HuthnalCart;
  const state = app.state;

  async function scanCart() {
    try {
      state.scannedProducts = app.productParser.scanProducts();
      await app.storage.refreshExistingPrices(state.scannedProducts);
      app.panelUi.renderProducts();
      return true;
    } catch (error) {
      console.error("장바구니 상품을 스캔하지 못했습니다.", error);
      state.status.textContent = "상품을 스캔하지 못했어요. 확장 프로그램 설정을 확인해 주세요.";
      app.panelUi.showToast("장바구니 스캔 중 오류가 발생했습니다.", true);
      return false;
    }
  }

  function scheduleScan() {
    clearTimeout(state.scanTimer);
    state.scanTimer = setTimeout(scanCart, app.scanDelayMs);
  }

  function initialize() {
    if (state.initialized || !location.pathname.toLowerCase().includes("cart")) return;
    state.initialized = true;
    app.panelUi.createPanel({
      onScan: scanCart,
      onImport: app.storage.importSelectedProducts
    });
    scheduleScan();

    state.observer = new MutationObserver((mutations) => {
      if (mutations.some((mutation) => !state.panel?.contains(mutation.target))) {
        scheduleScan();
      }
    });
    state.observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  initialize();
})();
