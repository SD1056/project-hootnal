(() => {
  if (globalThis.HuthnalCart) return;

  globalThis.HuthnalCart = {
    dayInMs: 24 * 60 * 60 * 1000,
    productRowSelector: ".cart-deal-item",
    scanDelayMs: 500,
    state: {
      selectedKeys: new Set(),
      writeQueue: Promise.resolve(),
      scanTimer: undefined,
      panel: undefined,
      shadow: undefined,
      productList: undefined,
      status: undefined,
      importButton: undefined,
      scannedProducts: [],
      existingKeys: new Set(),
      scanDiagnostics: { rows: 0, products: 0 },
      toastTimer: undefined,
      observer: undefined,
      initialized: false
    }
  };
})();
