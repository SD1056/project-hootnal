(() => {
  const app = globalThis.HuthnalCart;

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function parsePriceText(value) {
    if (/\(\s*\d+\s*\/\s*\d+\s*\)|\d+\s*\/\s*\d+/.test(value)) return null;
    const matches = [...value.matchAll(/(?:₩\s*([\d,]+)|([\d,]+)\s*(?:원|KRW))/gi)];
    const currencyMatch = matches.at(-1);
    const digits = (currencyMatch?.[1] || currencyMatch?.[2] || "").replace(/[^\d]/g, "");
    if (!digits) return null;
    const price = Number(digits);
    return Number.isSafeInteger(price) && price > 0 ? price : null;
  }

  function getPriceCandidates(root) {
    const elements = root.querySelectorAll(
      ".unit-total-price, .total-price, [class*='price'], strong, b, span, em, del"
    );
    const candidates = [];
    const seen = new Set();
    for (const element of elements) {
      if (element.closest("del,s, strike")) continue;
      const text = normalizeText(element.textContent);
      if (text.length > 40) continue;
      const price = parsePriceText(text);
      if (!price || seen.has(element)) continue;
      seen.add(element);
      const className = typeof element.className === "string" ? element.className : "";
      const classScore = /unit-total-price|total-price|final-price/i.test(className)
        ? 4
        : /price|amount/i.test(className)
          ? 3
          : 0;
      const tagScore = element.matches("strong,b") ? 2 : 0;
      const weightScore = Number.parseInt(getComputedStyle(element).fontWeight, 10) >= 600 ? 1 : 0;
      candidates.push({ element, price, score: classScore + tagScore + weightScore });
    }
    return candidates.sort((a, b) => b.score - a.score);
  }

  function isProductTitle(value) {
    const title = normalizeText(value);
    if (title.length < 6 || title.length > 180 || parsePriceText(title)) return false;
    return !/(만족했어요|한달구매|품절임박|남음|즉시할인|할인율|판매자로켓|로켓배송|내일 도착|무료배송|배송비|수량|옵션|찜하기|삭제|장바구니|쿠폰|적립|\(\s*\d+\s*\/\s*\d+\s*\)|^\d+\s*\/\s*\d+$)/.test(title);
  }

  function getProductLink(row) {
    return [...row.querySelectorAll("a[href]")].find((link) =>
      isProductTitle(link.textContent)
      && /\/(?:vp\/)?products?(?:\/|\.tmall)/i.test(new URL(link.href, location.href).pathname)
    ) || null;
  }

  function getProductTitle(row) {
    const productLink = getProductLink(row);
    const linkedTitle = productLink && normalizeText(productLink.textContent);
    if (linkedTitle && isProductTitle(linkedTitle)) return linkedTitle;

    const knownTitle = row.querySelector(
      ".product-name-part, .name, [class*='product-name'], [class*='productName'], [class*='prdName'], [class*='product_title']"
    );
    if (knownTitle && isProductTitle(knownTitle.textContent)) {
      return normalizeText(knownTitle.textContent);
    }
    const lines = (row.innerText || row.textContent || "")
      .split(/\n/)
      .map(normalizeText)
      .filter(isProductTitle);
    return lines.sort((a, b) => b.length - a.length)[0] || null;
  }

  function getCheckableElements() {
    return document.querySelectorAll(
      'input[type="checkbox"], [role="checkbox"], label:has(input[type="checkbox"])'
    );
  }

  function isCartProductRow(row) {
    if (!row.querySelector("img")) return false;
    if (getPriceCandidates(row).length === 0) return false;
    const checkables = row.querySelectorAll('input[type="checkbox"], [role="checkbox"]');
    return checkables.length === 1;
  }

  function getCartRowsFromCheckables() {
    const rows = new Set();
    for (const checkable of getCheckableElements()) {
      const identity = `${checkable.id || ""} ${checkable.getAttribute("name") || ""}`;
      const labelText = normalizeText(checkable.closest("label")?.textContent);
      if (/all|전체/i.test(identity) || /^(전체\s*선택|모두\s*선택)$/.test(labelText)) continue;
      let row = checkable.parentElement;
      for (let depth = 0; row && depth < 24; depth += 1, row = row.parentElement) {
        if (isCartProductRow(row)) {
          rows.add(row);
          break;
        }
      }
    }
    return [...rows];
  }

  function inferCategory(title) {
    const text = String(title || "").toLocaleLowerCase("ko-KR");
    const rules = [
      ["구독", /구독|멤버십|정기결제|넷플릭스|디즈니\+|유튜브 프리미엄|스포티파이/],
      ["디지털", /노트북|컴퓨터|키보드|마우스|모니터|휴대폰|스마트폰|이어폰|헤드폰|태블릿|카메라|전자/],
      ["패션", /신발|운동화|옷|의류|가방|코트|바지|원피스|패션/],
      ["뷰티", /화장품|스킨케어|향수|립스틱|크림|세럼|뷰티|샴푸/],
      ["생활", /가구|수납|청소|주방|침대|의자|책상|생활|행거|선반/],
      ["식품", /치킨|식품|간식|커피|음료|과자|식료품|밀키트/],
      ["취미", /게임|레고|악기|캠핑|운동|취미|책|도서|자전거/]
    ];
    return rules.find(([, pattern]) => pattern.test(text))?.[0] || "기타";
  }

  function makeProduct(row, title, price) {
    const productLink = getProductLink(row);
    const productUrl = productLink
      ? new URL(productLink.href, location.href)
      : null;
    const checkbox = row.querySelector('input[type="checkbox"], [role="checkbox"]');
    const checkboxId = checkbox && `${checkbox.id || ""} ${checkbox.getAttribute("name") || ""}`.trim();
    const productIdentity = productUrl ? `${productUrl.pathname}${productUrl.search}` : "";
    const rowId = row.dataset.cartDealId
      || row.dataset.productId
      || (checkboxId && !/all|전체/i.test(checkboxId) ? checkboxId : "")
      || productIdentity;
    const source = location.hostname.endsWith("coupang.com")
      ? "coupang"
      : location.hostname === "shopping.naver.com"
        ? "naver"
        : "11st";
    return {
      title,
      price,
      category: inferCategory(title),
      recurring: /정기\s*결제|월\s*구독|매월\s*결제|멤버십|구독권/i.test(title),
      cadence: "monthly",
      sourceKey: `${source}:${rowId || title.toLocaleLowerCase("ko-KR")}`
    };
  }

  function getProduct(row) {
    if (!isCartProductRow(row)) return null;
    const title = getProductTitle(row);
    const price = getPriceCandidates(row)[0]?.price;
    if (!title || !price) return null;
    return makeProduct(row, title, price);
  }

  function scanProducts() {
    const productRows = [...new Set([
      ...document.querySelectorAll(app.productRowSelector),
      ...getCartRowsFromCheckables()
    ])].filter(isCartProductRow);
    const productsByKey = new Map(
      productRows.map(getProduct).filter(Boolean).map((product) => [product.sourceKey, product])
    );
    app.state.scanDiagnostics = { rows: productRows.length, products: productsByKey.size };
    return [...productsByKey.values()];
  }

  app.productParser = { scanProducts };
})();
