(() => {
  const app = globalThis.HuthnalCart;
  const state = app.state;

  async function refreshExistingPrices(products) {
    const stored = await chrome.storage.local.get("items");
    const items = Array.isArray(stored.items) ? stored.items : [];
    state.existingKeys = new Set(items.map((item) => item.sourceKey).filter(Boolean));
    let priceHistoryChanged = false;
    const now = Date.now();

    for (const product of products) {
      const existing = items.find((item) => item.sourceKey === product.sourceKey);
      if (!existing) continue;
      if (!Array.isArray(existing.priceHistory)) existing.priceHistory = [];
      if (existing.price !== product.price) {
        existing.priceHistory.push({ at: now, price: product.price });
        existing.price = product.price;
        priceHistoryChanged = true;
      } else if (existing.priceHistory.length === 0) {
        existing.priceHistory.push({ at: now, price: product.price });
        priceHistoryChanged = true;
      }
    }

    if (priceHistoryChanged) await chrome.storage.local.set({ items });
  }

  function importSelectedProducts() {
    const selectedProducts = state.scannedProducts.filter((product) =>
      state.selectedKeys.has(product.sourceKey) && !state.existingKeys.has(product.sourceKey)
    );
    if (selectedProducts.length === 0) return Promise.resolve();

    state.importButton.disabled = true;
    state.status.textContent = "선택한 상품을 보류 목록에 저장하고 있어요...";
    state.writeQueue = state.writeQueue.then(async () => {
      const stored = await chrome.storage.local.get("items");
      const items = Array.isArray(stored.items) ? stored.items : [];
      const keys = new Set(items.map((item) => item.sourceKey).filter(Boolean));
      const newItems = selectedProducts
        .filter((product) => !keys.has(product.sourceKey))
        .map((product) => {
          const addedAt = Date.now();
          return {
            id: crypto.randomUUID(),
            ...product,
            priceHistory: [{ at: addedAt, price: product.price }],
            addedAt,
            reviewAt: addedAt + app.dayInMs,
            status: "waiting"
          };
        });

      if (newItems.length > 0) {
        const activityStored = await chrome.storage.local.get("activityEvents");
        const events = Array.isArray(activityStored.activityEvents) ? activityStored.activityEvents : [];
        const newEvents = newItems.map((item) => ({
          id: crypto.randomUUID(),
          type: "temptation",
          at: item.addedAt,
          title: item.title,
          price: item.price,
          category: item.category || "기타",
          riskScore: 0,
          recurring: Boolean(item.recurring),
          hour: new Date(item.addedAt).getHours(),
          dayOfMonth: new Date(item.addedAt).getDate()
        }));
        await chrome.storage.local.set({
          items: [...items, ...newItems],
          activityEvents: [...events, ...newEvents]
        });
      }

      newItems.forEach((item) => {
        state.existingKeys.add(item.sourceKey);
        state.selectedKeys.delete(item.sourceKey);
      });
      state.status.textContent = newItems.length > 0
        ? `${newItems.length}개 상품을 24시간 보류 목록에 담았어요.`
        : "선택한 상품은 이미 보류 목록에 담겨 있어요.";
      app.panelUi.showToast(newItems.length > 0
        ? `성공적으로 ${newItems.length}개의 상품을 담았습니다.`
        : "선택한 상품은 이미 보류 목록에 담겨 있습니다.");
      app.panelUi.renderProducts();
    }).catch((error) => {
      console.error("선택한 상품을 보류 목록에 저장하지 못했습니다.", error);
      state.status.textContent = "저장하지 못했어요. 다시 시도해 주세요.";
      app.panelUi.showToast("상품 저장 중 오류가 발생했습니다.", true);
      app.panelUi.renderProducts();
    });
    return state.writeQueue;
  }

  app.storage = { refreshExistingPrices, importSelectedProducts };
})();
