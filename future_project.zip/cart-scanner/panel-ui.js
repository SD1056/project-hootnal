(() => {
  const state = globalThis.HuthnalCart.state;

  function makeElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  function addStyles() {
    const style = document.createElement("style");
    style.textContent = `
      :host { all: initial; }
      * { box-sizing: border-box; }
      .panel {
        position: fixed; right: 20px; bottom: 20px; z-index: 2147483647;
        width: min(370px, calc(100vw - 32px)); max-height: min(580px, calc(100vh - 32px));
        display: flex; flex-direction: column; overflow: hidden;
        border: 1px solid #d8e8f6; border-radius: 16px; background: #fff;
        color: #1e3347; box-shadow: 0 8px 32px rgba(20, 70, 120, .18);
        font: 13px/1.5 "Segoe UI", "Malgun Gothic", sans-serif;
      }
      header { padding: 16px 18px 12px; background: linear-gradient(145deg, #328ad6 0%, #1f72b8 100%); color: #fff; }
      h2 { margin: 0; font-size: 16px; }
      .subtitle { margin: 4px 0 0; color: #e1f0fc; font-size: 11px; }
      .status { margin: 0; padding: 10px 16px; color: #4a6782; font-size: 12px; }
      .products { display: grid; gap: 8px; overflow-y: auto; padding: 0 12px 12px; }
      .product {
        display: grid; grid-template-columns: 18px minmax(0, 1fr); gap: 9px;
        padding: 10px; border: 1px solid #d8e8f6; border-radius: 10px;
        background: #fff; box-shadow: 0 1px 3px rgb(40 120 180 / 4%);
      }
      .product input { width: 16px; height: 16px; margin: 2px 0 0; accent-color: #2b8ed9; }
      .product input:disabled { cursor: not-allowed; }
      .title { margin: 0; overflow-wrap: anywhere; font-size: 12px; font-weight: 650; color: #1e3347; }
      .price { margin: 3px 0 0; color: #1773ba; font-size: 12px; font-weight: 750; }
      .duplicate { margin: 3px 0 0; color: #728ea6; font-size: 10px; }
      .empty { padding: 8px 4px 12px; color: #728ea6; text-align: center; }
      footer { display: grid; gap: 8px; padding: 12px; border-top: 1px solid #d8e8f6; background: #fafcff; }
      .selection-actions { display: flex; gap: 8px; }
      button {
        min-height: 36px; padding: 7px 10px; border: 1px solid #d4e5f4;
        border-radius: 9px; background: #f4faff; color: #1768a3;
        font: 650 11px "Segoe UI", "Malgun Gothic", sans-serif; cursor: pointer;
      }
      button:hover { background: #e7f3fd; }
      button:focus-visible, input:focus-visible { outline: 3px solid #7cbbe8; outline-offset: 2px; }
      .selection-actions button { flex: 1; }
      .import-button { border-color: #278dd9; background: #278dd9; box-shadow: 0 2px 8px rgb(39 141 217 / 25%); color: #fff; font-size: 12px; }
      .import-button:hover { background: #1b7bc3; }
      .import-button:disabled { border-color: #c5d8e8; background: #c5d8e8; box-shadow: none; cursor: not-allowed; }
      .toast { position: fixed; right: 16px; bottom: 16px; z-index: 2; display: flex; align-items: center; gap: 9px; width: min(340px, calc(100vw - 32px)); padding: 12px 14px; border: 1px solid #cce3f7; border-radius: 10px; background: #fff; color: #15456f; box-shadow: 0 5px 18px rgba(25, 85, 140, .14); opacity: 0; transform: translateX(24px); transition: opacity 200ms ease, transform 240ms cubic-bezier(.2,.7,.25,1); pointer-events: none; }
      .toast.is-visible { opacity: 1; transform: translateX(0); }
      .toast.is-leaving { opacity: 0; transform: translateX(28px); pointer-events: none; }
      .toast.is-error { border-color: #ead8d3; color: #8a4339; }
      .toast-mark { flex: 0 0 8px; width: 8px; height: 8px; border-radius: 50%; background: #3299ea; }
      .toast.is-error .toast-mark { background: #b45e4d; }
      .toast-message { font-size: 12px; font-weight: 650; }
      @media (prefers-reduced-motion: reduce) {
        .toast { transition: none; }
      }
      @media (max-width: 430px) {
        .panel { right: 8px; bottom: 8px; width: calc(100vw - 16px); }
      }
    `;
    state.shadow.append(style);
  }

  function showToast(message, isError = false) {
    clearTimeout(state.toastTimer);
    const previousToast = state.shadow.querySelector(".toast");
    if (previousToast && !previousToast.classList.contains("is-leaving")) {
      previousToast.classList.remove("is-visible");
      previousToast.classList.add("is-leaving");
      setTimeout(() => previousToast.remove(), 260);
    }
    const toast = makeElement("div", `toast${isError ? " is-error" : ""}`);
    toast.setAttribute("role", isError ? "alert" : "status");
    toast.append(makeElement("span", "toast-mark"), makeElement("span", "toast-message", message));
    state.shadow.append(toast);
    requestAnimationFrame(() => {
      if (toast.isConnected && !toast.classList.contains("is-leaving")) {
        toast.classList.add("is-visible");
      }
    });
    state.toastTimer = setTimeout(() => {
      if (!toast.isConnected || toast.classList.contains("is-leaving")) return;
      toast.classList.remove("is-visible");
      toast.classList.add("is-leaving");
      const exitDuration = matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 260;
      setTimeout(() => toast.remove(), exitDuration);
    }, 3600);
  }

  function updateImportButton() {
    const selectedCount = state.scannedProducts.filter((product) =>
      state.selectedKeys.has(product.sourceKey) && !state.existingKeys.has(product.sourceKey)
    ).length;
    state.importButton.disabled = selectedCount === 0;
    state.importButton.textContent = selectedCount > 0
      ? `선택한 ${selectedCount}개 상품을 훗날에 담기`
      : "보류할 상품을 선택해 주세요";
  }

  function renderProducts() {
    state.productList.replaceChildren();
    if (state.scannedProducts.length === 0) {
      state.productList.append(makeElement(
        "p",
        "empty",
        `체크박스가 있는 장바구니 상품을 찾지 못했어요. (장바구니 행 ${state.scanDiagnostics.rows}개, 상품 ${state.scanDiagnostics.products}개)`
      ));
      state.status.textContent = "상품 정보를 확인할 수 없습니다. 장바구니 상품의 선택 체크박스를 확인해 주세요.";
      updateImportButton();
      return;
    }

    state.status.textContent = `${state.scannedProducts.length}개 상품을 찾았어요. 보류할 상품을 선택해 주세요.`;
    state.scannedProducts.forEach((product) => {
      const row = makeElement("label", "product");
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = state.selectedKeys.has(product.sourceKey);
      checkbox.disabled = state.existingKeys.has(product.sourceKey);
      checkbox.setAttribute("aria-label", `${product.title} ${product.price}원 선택`);
      checkbox.addEventListener("change", () => {
        if (checkbox.checked) state.selectedKeys.add(product.sourceKey);
        else state.selectedKeys.delete(product.sourceKey);
        updateImportButton();
      });

      const details = makeElement("div");
      details.append(
        makeElement("p", "title", product.title),
        makeElement("p", "price", `${new Intl.NumberFormat("ko-KR").format(product.price)}원`)
      );
      if (state.existingKeys.has(product.sourceKey)) {
        details.append(makeElement("p", "duplicate", "이미 보류 목록에 담긴 상품입니다."));
        state.selectedKeys.delete(product.sourceKey);
      }
      row.append(checkbox, details);
      state.productList.append(row);
    });
    updateImportButton();
  }

  function createPanel({ onScan, onImport }) {
    if (state.panel || !document.body) return;
    state.panel = document.createElement("div");
    state.panel.id = "future-cart-selector";
    state.shadow = state.panel.attachShadow({ mode: "closed" });
    addStyles();

    const container = makeElement("section", "panel");
    container.setAttribute("aria-label", "훗날 보류 상품 선택");
    const header = document.createElement("header");
    header.append(
      makeElement("h2", "", "훗날에 담을 상품 선택"),
      makeElement("p", "subtitle", "선택한 상품만 24시간 보류 목록으로 옮깁니다.")
    );
    state.status = makeElement("p", "status", "장바구니 상품을 찾는 중...");
    state.productList = makeElement("div", "products");
    state.productList.setAttribute("role", "group");
    state.productList.setAttribute("aria-label", "장바구니 상품");

    const footer = document.createElement("footer");
    const selectionActions = makeElement("div", "selection-actions");
    const selectAllButton = makeElement("button", "", "전체 선택");
    selectAllButton.type = "button";
    selectAllButton.addEventListener("click", () => {
      state.scannedProducts
        .filter((product) => !state.existingKeys.has(product.sourceKey))
        .forEach((product) => state.selectedKeys.add(product.sourceKey));
      renderProducts();
      showToast("추가 가능한 상품을 모두 선택했습니다.");
    });
    const clearButton = makeElement("button", "", "선택 해제");
    clearButton.type = "button";
    clearButton.addEventListener("click", () => {
      state.selectedKeys.clear();
      renderProducts();
      showToast("상품 선택을 모두 해제했습니다.");
    });
    selectionActions.append(selectAllButton, clearButton);

    const scanButton = makeElement("button", "", "다시 스캔");
    scanButton.type = "button";
    scanButton.addEventListener("click", async () => {
      const scanSucceeded = await onScan();
      if (!scanSucceeded) return;
      showToast(state.scannedProducts.length
        ? `${state.scannedProducts.length}개의 장바구니 상품을 확인했습니다.`
        : "확인 가능한 장바구니 상품이 없습니다.", state.scannedProducts.length === 0);
    });
    state.importButton = makeElement("button", "import-button", "보류할 상품을 선택해 주세요");
    state.importButton.type = "button";
    state.importButton.disabled = true;
    state.importButton.addEventListener("click", () => onImport());
    footer.append(selectionActions, scanButton, state.importButton);
    container.append(header, state.status, state.productList, footer);
    state.shadow.append(container);
    document.body.append(state.panel);
  }

  globalThis.HuthnalCart.panelUi = {
    createPanel,
    renderProducts,
    showToast
  };
})();
