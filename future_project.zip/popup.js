const DAY_IN_MS = 24 * 60 * 60 * 1000;
const DEFAULT_DATA = {
  items: [],
  goals: [],
  activeGoalId: "",
  settings: {
    riskDelaySeconds: { low: 60, medium: 300, high: 1800 },
    hourlyWage: 0,
    chickenPrice: 20000,
    subscriptionPrice: 13500,
    streakEnabled: true,
    monthlyBudget: 0,
    nightModeEnabled: false,
    nightStartHour: 22,
    nightEndHour: 6,
    nightDelayMinutes: 30,
    nightRequireConfirmation: true,
    personalPledge: ""
  }
};

const itemForm = document.querySelector("#item-form");
const itemTitleInput = document.querySelector("#item-title");
const itemPriceInput = document.querySelector("#item-price");
const usageFrequencyInput = document.querySelector("#usage-frequency");
const usageYearsInput = document.querySelector("#usage-years");
const purchaseInsight = document.querySelector("#purchase-insight");
const itemCategoryInput = document.querySelector("#item-category");
const itemRecurringInput = document.querySelector("#item-recurring");
const itemCadenceInput = document.querySelector("#item-cadence");
const regretWarning = document.querySelector("#regret-warning");
const settingsForm = document.querySelector("#settings-form");
const goalForm = document.querySelector("#goal-form");
const goalNameInput = document.querySelector("#goal-name");
const goalAmountInput = document.querySelector("#goal-amount");
const lowRiskDelayInput = document.querySelector("#risk-delay-low");
const mediumRiskDelayInput = document.querySelector("#risk-delay-medium");
const highRiskDelayInput = document.querySelector("#risk-delay-high");
const streakEnabledInput = document.querySelector("#streak-enabled");
const monthlyBudgetInput = document.querySelector("#monthly-budget");
const nightModeEnabledInput = document.querySelector("#night-mode-enabled");
const nightStartHourInput = document.querySelector("#night-start-hour");
const nightEndHourInput = document.querySelector("#night-end-hour");
const nightDelayMinutesInput = document.querySelector("#night-delay-minutes");
const nightRequireConfirmationInput = document.querySelector("#night-require-confirmation");
const streakCard = document.querySelector("#streak-card");
const streakCount = document.querySelector("#streak-count");
const streakBadges = document.querySelector("#streak-badges");
const personalPledgeInput = document.querySelector("#personal-pledge");
const personalPledgeDisplay = document.querySelector("#personal-pledge-display");
const opportunityCopy = document.querySelector("#opportunity-copy");
const opportunityAssumptions = document.querySelector("#opportunity-assumptions");
const goalList = document.querySelector("#goal-list");
const goalCount = document.querySelector("#goal-count");
const goalEmptyState = document.querySelector("#goal-empty-state");
const followupList = document.querySelector("#followup-list");
const followupCount = document.querySelector("#followup-count");
const followupEmptyState = document.querySelector("#followup-empty-state");
const reportTemptations = document.querySelector("#report-temptations");
const reportResisted = document.querySelector("#report-resisted");
const reportPurchased = document.querySelector("#report-purchased");
const reportCategory = document.querySelector("#report-category");
const reportTime = document.querySelector("#report-time");
const reportHourChart = document.querySelector("#report-hour-chart");
const reportRecurring = document.querySelector("#report-recurring");
const itemList = document.querySelector("#item-list");
const emptyState = document.querySelector("#empty-state");
const itemCount = document.querySelector("#item-count");
const savedTotal = document.querySelector("#saved-total");
const goalCaption = document.querySelector("#goal-caption");
const goalPercentage = document.querySelector("#goal-percentage");
const goalInsight = document.querySelector("#goal-insight");
const progressTrack = document.querySelector("#progress-track");
const progressFill = document.querySelector("#progress-fill");
const toastRegion = document.querySelector("#toast-region");
const alertPopup = document.querySelector("#alert-popup");
const alertPopupCard = alertPopup.querySelector(".alert-popup-card");
const alertPopupMessage = document.querySelector("#alert-popup-message");
const alertPopupClose = document.querySelector("#alert-popup-close");
const homeWaitingCount = document.querySelector("#home-waiting-count");
let toastTimer;
let previousAlertFocus;
let activeView = "home";
let viewTransitionId = 0;
let viewAnimation;
let viewTimer;
let reportPeriod = "week";
const viewTransitionDuration = 160;

const currencyFormatter = new Intl.NumberFormat("ko-KR", {
  style: "currency",
  currency: "KRW",
  maximumFractionDigits: 0
});

function formatCurrency(amount) {
  return currencyFormatter.format(amount);
}

function showToast(message, type = "success") {
  if (!message) return;
  clearTimeout(toastTimer);
  toastRegion.querySelectorAll(".toast").forEach(dismissToast);
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.setAttribute("role", type === "error" ? "alert" : "status");
  const marker = document.createElement("span");
  marker.className = "toast-marker";
  marker.setAttribute("aria-hidden", "true");
  const text = document.createElement("span");
  text.className = "toast-message";
  text.textContent = message;
  const close = document.createElement("button");
  close.className = "toast-close";
  close.type = "button";
  close.setAttribute("aria-label", "알림 닫기");
  close.textContent = "×";
  close.addEventListener("click", () => dismissToast(toast));
  toast.append(marker, text, close);
  toastRegion.append(toast);
  requestAnimationFrame(() => {
    if (toast.isConnected && !toast.classList.contains("is-leaving")) {
      toast.classList.add("is-visible");
    }
  });
  toastTimer = setTimeout(() => dismissToast(toast), 3600);
}

function dismissToast(toast) {
  if (!toast.isConnected || toast.classList.contains("is-leaving")) return;
  toast.classList.remove("is-visible");
  toast.classList.add("is-leaving");
  const exitDuration = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 260;
  setTimeout(() => toast.remove(), exitDuration);
}

function showMessage(message, isError = true) {
  if (!isError) {
    showToast(message, "success");
    return;
  }
  if (alertPopup.hidden) previousAlertFocus = document.activeElement;
  alertPopupMessage.textContent = message;
  alertPopup.hidden = false;
  alertPopupClose.focus();
}

function closeAlertPopup() {
  alertPopup.hidden = true;
  if (previousAlertFocus instanceof HTMLElement && previousAlertFocus.isConnected) {
    previousAlertFocus.focus();
  }
  previousAlertFocus = undefined;
}

function switchView(name) {
  const pages = [...document.querySelectorAll("[data-page]")];
  const next = pages.find((page) => page.dataset.page === name);
  if (name === activeView || !next) return;
  const transitionId = ++viewTransitionId;
  clearTimeout(viewTimer);
  viewAnimation?.cancel();
  viewAnimation = undefined;
  const current = pages.find((page) => !page.hidden);
  if (!current) return;
  pages.forEach((page) => {
    page.hidden = page !== current;
  });
  const currentTab = document.querySelector(`[data-view="${activeView}"]`);
  const nextTab = document.querySelector(`[data-view="${name}"]`);
  if (currentTab) {
    currentTab.classList.remove("is-active");
    currentTab.setAttribute("aria-selected", "false");
  }
  if (nextTab) {
    nextTab.classList.add("is-active");
    nextTab.setAttribute("aria-selected", "true");
  }
  activeView = name;

  const showNextView = () => {
    if (transitionId !== viewTransitionId) return;
    current.hidden = true;
    next.hidden = false;
    viewAnimation = next.animate(
      [{ opacity: 0 }, { opacity: 1 }],
      { duration: viewTransitionDuration, easing: "ease-out" }
    );
    const enterAnimation = viewAnimation;
    const finishEnter = () => {
      if (transitionId !== viewTransitionId || viewAnimation !== enterAnimation) return;
      clearTimeout(viewTimer);
      enterAnimation.cancel();
      viewAnimation = undefined;
      viewTimer = undefined;
    };
    viewTimer = setTimeout(finishEnter, viewTransitionDuration + 80);
    enterAnimation.finished.then(finishEnter).catch(() => {});
  };

  viewAnimation = current.animate(
    [{ opacity: 1 }, { opacity: 0 }],
    { duration: viewTransitionDuration, easing: "ease-in" }
  );
  const exitAnimation = viewAnimation;
  const finishExit = () => {
    if (transitionId !== viewTransitionId || viewAnimation !== exitAnimation) return;
    clearTimeout(viewTimer);
    exitAnimation.cancel();
    showNextView();
  };
  viewTimer = setTimeout(finishExit, viewTransitionDuration + 80);
  exitAnimation.finished.then(finishExit).catch(() => {});
}

async function readData() {
  const stored = await chrome.storage.local.get(["items", "goal", "goals", "activeGoalId", "settings", "activityEvents"]);
  let goals = Array.isArray(stored.goals) ? stored.goals : [];
  if (!Array.isArray(stored.goals) && stored.goal?.name && stored.goal?.amount) {
    goals = [{ id: "legacy-goal", name: stored.goal.name, amount: stored.goal.amount, createdAt: 0 }];
  }

  const activeGoalId = goals.some((goal) => goal.id === stored.activeGoalId)
    ? stored.activeGoalId
    : goals[0]?.id || "";
  return {
    items: Array.isArray(stored.items) ? stored.items : DEFAULT_DATA.items,
    events: Array.isArray(stored.activityEvents) ? stored.activityEvents : [],
    goals,
    activeGoalId,
    goal: goals.find((goal) => goal.id === activeGoalId) || { name: "", amount: 0 },
    settings: stored.settings && typeof stored.settings === "object"
      ? {
          ...DEFAULT_DATA.settings,
          ...stored.settings,
          riskDelaySeconds: stored.settings.riskDelaySeconds
            && typeof stored.settings.riskDelaySeconds === "object"
            ? { ...DEFAULT_DATA.settings.riskDelaySeconds, ...stored.settings.riskDelaySeconds }
            : {
                low: Number(stored.settings.delaySeconds) || DEFAULT_DATA.settings.riskDelaySeconds.low,
                medium: Number(stored.settings.delaySeconds) || DEFAULT_DATA.settings.riskDelaySeconds.medium,
                high: Number(stored.settings.delaySeconds) || DEFAULT_DATA.settings.riskDelaySeconds.high
              }
        }
      : DEFAULT_DATA.settings
  };
}

function getLocalDateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function getStreakStats(events) {
  const days = [...new Set(events
    .filter((event) => event.type === "resisted" && Number.isFinite(event.at))
    .map((event) => getLocalDateKey(new Date(event.at))))]
    .sort();
  const daySet = new Set(days);
  const today = new Date();
  const anchor = daySet.has(getLocalDateKey(today))
    ? today
    : new Date(today.getFullYear(), today.getMonth(), today.getDate() - 1);
  let current = 0;
  for (let offset = 0; ; offset += 1) {
    const date = new Date(anchor.getFullYear(), anchor.getMonth(), anchor.getDate() - offset);
    if (!daySet.has(getLocalDateKey(date))) break;
    current += 1;
  }

  let best = 0;
  let run = 0;
  let previous;
  days.forEach((key) => {
    const [year, month, day] = key.split("-").map(Number);
    const date = new Date(Date.UTC(year, month - 1, day));
    const gap = previous ? (date - previous) / DAY_IN_MS : 0;
    run = gap === 1 ? run + 1 : 1;
    best = Math.max(best, run);
    previous = date;
  });
  return { current, best };
}

function renderStreak(data) {
  const enabled = data.settings.streakEnabled !== false;
  streakCard.hidden = !enabled;
  if (!enabled) return;
  const stats = getStreakStats(data.events);
  streakCount.textContent = String(stats.current);
  streakBadges.replaceChildren();
  [3, 7, 14, 30].forEach((milestone) => {
    const badge = document.createElement("span");
    badge.className = stats.best >= milestone ? "streak-badge is-earned" : "streak-badge";
    badge.textContent = `${milestone}일`;
    badge.title = stats.best >= milestone ? `${milestone}일 연속 절약 배지 획득` : `${milestone}일 연속 절약 시 획득`;
    streakBadges.append(badge);
  });
}

function inferCategory(title) {
  const text = String(title || "").toLocaleLowerCase("ko-KR");
  const rules = [
    ["구독", /구독|멤버십|정기결제|넷플릭스|디즈니\+|유튜브 프리미엄|스포티파이/],
    ["디지털", /노트북|컴퓨터|키보드|마우스|모니터|휴대폰|스마트폰|이어폰|헤드폰|태블릿|카메라|전자/],
    ["패션", /신발|운동화|옷|의류|가방|코트|바지|원피스|상의|하의|패션/],
    ["뷰티", /화장품|스킨케어|향수|립스틱|크림|세럼|뷰티|샴푸/],
    ["생활", /가구|수납|청소|주방|침대|의자|책상|생활|행거|선반/],
    ["식품", /치킨|식품|간식|커피|음료|과자|식료품|밀키트/],
    ["취미", /게임|레고|악기|캠핑|운동|취미|책|도서|자전거/]
  ];
  return rules.find(([, pattern]) => pattern.test(text))?.[0] || "기타";
}

function annualRecurringCost(price, cadence) {
  const yearlyPayments = { monthly: 12, quarterly: 4, yearly: 1 };
  return price * (yearlyPayments[cadence] || 0);
}

function hasRegrettedSimilarItem(title, items) {
  const tokens = normalizeTokens(title);
  if (!tokens.length) return null;
  return items.find((item) => {
    if (!item.regretRecorded || item.regret !== true) return false;
    const previousTokens = normalizeTokens(item.title);
    const shared = tokens.filter((token) => previousTokens.includes(token)).length;
    return shared > 0 && shared / Math.max(tokens.length, previousTokens.length) >= 0.4;
  }) || null;
}

function normalizeTokens(title) {
  return String(title || "")
    .toLocaleLowerCase("ko-KR")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((token) => token.length >= 2 && !/^(정품|신제품|무료배송|로켓배송)$/.test(token));
}

async function saveData(data) {
  await chrome.storage.local.set(data);
}

function getSavedAmount(items) {
  return items
    .filter((item) => item.status === "saved")
    .reduce((total, item) => total + item.price, 0);
}

function getGoalInsight(saved, goal) {
  if (!goal.name || !goal.amount) {
    return "작은 보류가 원하는 내일에 가까워지게 해요.";
  }
  if (saved >= goal.amount) {
    return `${goal.name} 목표를 달성했어요. ${formatCurrency(saved - goal.amount)} 더 모았어요.`;
  }
  return `${goal.name}까지 ${formatCurrency(goal.amount - saved)} 남았어요.`;
}

function formatWorkTime(price, hourlyWage) {
  if (!hourlyWage || hourlyWage < 1) return "";
  const minutes = Math.ceil((price / hourlyWage) * 60);
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return hours > 0
    ? `${hours}시간${rest ? ` ${rest}분` : ""}`
    : `${Math.max(1, rest)}분`;
}

function getUseCost(price, frequency, years) {
  if (!frequency || !years || frequency < 1 || years <= 0) return null;
  return Math.max(1, Math.round(price / (frequency * 52 * years)));
}

function getOpportunityCost(price, settings) {
  const chickenPrice = Math.max(1, Number(settings.chickenPrice) || DEFAULT_DATA.settings.chickenPrice);
  const subscriptionPrice = Math.max(1, Number(settings.subscriptionPrice) || DEFAULT_DATA.settings.subscriptionPrice);
  const chickens = price / chickenPrice;
  const months = price / subscriptionPrice;
  const futureValue = Math.round(price * Math.pow(1.07, 10));
  return `${chickens.toFixed(chickens >= 10 ? 0 : 1)}마리 치킨 · 구독 ${months.toFixed(months >= 10 ? 0 : 1)}개월 · 10년 뒤 약 ${formatCurrency(futureValue)}`;
}

function renderSummary(data) {
  const saved = getSavedAmount(data.items);
  const goal = data.goal;
  const percentage = goal.amount > 0
    ? Math.min(100, Math.floor((saved / goal.amount) * 100))
    : 0;

  savedTotal.textContent = formatCurrency(saved);
  goalCaption.textContent = goal.name && goal.amount
    ? `${goal.name} · ${formatCurrency(goal.amount)}`
    : "목표를 설정해 보세요";
  goalPercentage.textContent = `${percentage}%`;
  goalInsight.textContent = getGoalInsight(saved, goal);
  progressFill.style.width = `${percentage}%`;
  progressTrack.setAttribute("aria-valuenow", String(percentage));
}

function makeButton(label, action, disabled = false, className = "") {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = label;
  button.dataset.action = action;
  button.disabled = disabled;
  if (className) button.className = className;
  return button;
}

function appendItemInsights(card, item, settings) {
  const details = [];
  const workTime = formatWorkTime(item.price, settings.hourlyWage);
  const useCost = getUseCost(item.price, item.usageFrequency, item.usageYears);
  if (workTime) details.push(`내 시급 기준 약 ${workTime} 일해야 하는 금액`);
  if (useCost) details.push(`예상 1회 사용 비용 ${formatCurrency(useCost)} · 주 ${item.usageFrequency}회, ${item.usageYears}년 사용`);
  if (item.recurring) {
    details.push(`연간 반복 지출 약 ${formatCurrency(annualRecurringCost(item.price, item.cadence))}`);
  }
  if (Array.isArray(item.priceHistory) && item.priceHistory.length > 1) {
    const lowest = Math.min(...item.priceHistory.map((entry) => entry.price));
    const aboveLow = lowest > 0 ? Math.round(((item.price - lowest) / lowest) * 100) : 0;
    details.push(`최저 기록 ${formatCurrency(lowest)} 대비 ${aboveLow}%`);
  }
  if (details.length > 0) {
    const insight = document.createElement("p");
    insight.className = "item-insight";
    insight.textContent = details.join(" · ");
    card.append(insight);
  }
}

function makeGoalCard(goal, saved, activeGoalId) {
  const card = document.createElement("li");
  card.className = "goal-card";
  const heading = document.createElement("div");
  heading.className = "item-heading";
  const name = document.createElement("p");
  name.className = "item-title";
  name.textContent = goal.name;
  const target = document.createElement("span");
  target.className = "item-price";
  target.textContent = formatCurrency(goal.amount);
  heading.append(name, target);

  const percentage = goal.amount > 0 ? Math.min(100, Math.floor((saved / goal.amount) * 100)) : 0;
  const progress = document.createElement("div");
  progress.className = "goal-card-progress";
  progress.setAttribute("role", "progressbar");
  progress.setAttribute("aria-label", `${goal.name} 목표 달성률`);
  progress.setAttribute("aria-valuenow", String(percentage));
  const fill = document.createElement("span");
  fill.style.width = `${percentage}%`;
  progress.append(fill);

  const details = document.createElement("p");
  details.className = "goal-card-detail";
  details.textContent = `${formatCurrency(saved)} 모음 · ${percentage}% 달성 · ${formatCurrency(Math.max(0, goal.amount - saved))} 남음`;
  const actions = document.createElement("div");
  actions.className = "goal-card-actions";
  const activate = document.createElement("button");
  activate.type = "button";
  activate.dataset.goalAction = "activate";
  activate.dataset.goalId = goal.id;
  activate.disabled = activeGoalId === goal.id;
  activate.textContent = activeGoalId === goal.id ? "홈 목표로 설정됨" : "홈 목표로 설정";
  const remove = document.createElement("button");
  remove.type = "button";
  remove.dataset.goalAction = "delete";
  remove.dataset.goalId = goal.id;
  remove.className = "delete-button";
  remove.textContent = "삭제";
  actions.append(activate, remove);
  card.append(heading, progress, details, actions);
  return card;
}

function makeItemCard(item, goal, settings) {
  const card = document.createElement("li");
  card.className = "item-card";
  card.dataset.itemId = item.id;

  const heading = document.createElement("div");
  heading.className = "item-heading";
  const title = document.createElement("p");
  title.className = "item-title";
  title.textContent = item.title;
  const price = document.createElement("span");
  price.className = "item-price";
  price.textContent = formatCurrency(item.price);
  heading.append(title, price);
  card.append(heading);
  appendItemInsights(card, item, settings);
  if (item.category) {
    const category = document.createElement("p");
    category.className = "item-meta";
    category.textContent = item.category;
    card.append(category);
  }

  if (item.status === "waiting") {
    const reviewReady = Date.now() >= item.reviewAt;
    const timing = document.createElement("p");
    timing.className = reviewReady ? "item-status is-ready" : "item-timing";
    timing.textContent = reviewReady
      ? "다시 생각해 볼 시간이 됐어요."
      : `다시 보기: ${new Date(item.reviewAt).toLocaleString("ko-KR", {
          month: "numeric",
          day: "numeric",
          hour: "2-digit",
          minute: "2-digit"
        })}`;
    card.append(timing);

    if (goal.name && goal.amount) {
      const insight = document.createElement("p");
      insight.className = "item-insight";
      const percentagePoints = (item.price / goal.amount) * 100;
      insight.textContent = `안 사면 ${goal.name} 목표에 ${percentagePoints < 0.1 ? "0.1% 미만" : `${percentagePoints.toFixed(percentagePoints < 10 ? 1 : 0)}%p`} 가까워져요.`;
      card.append(insight);
    }

    const actions = document.createElement("div");
    actions.className = "item-actions";
    actions.append(
      makeButton("필요한 물건이에요", "bought", !reviewReady),
      makeButton("안 사기로 했어요", "saved", !reviewReady),
      makeButton("삭제", "delete", false, "delete-button")
    );
    card.append(actions);
  } else {
    const status = document.createElement("p");
    status.className = "item-status";
    status.textContent = item.status === "saved"
      ? `안 사기로 했어요 · ${new Date(item.resolvedAt).toLocaleDateString("ko-KR")}`
      : item.status === "checkout_pending"
        ? `구매 의사를 기록했어요 · 실제 구매 여부는 확인되지 않았어요`
        : item.status === "not_bought"
          ? `실제 구매하지 않았다고 기록했어요`
          : `구매하기로 했어요 · ${new Date(item.resolvedAt).toLocaleDateString("ko-KR")}`;
    card.append(status);
    const actions = document.createElement("div");
    actions.className = "item-actions";
    actions.append(makeButton("기록 삭제", "delete", false, "delete-button"));
    card.append(actions);
  }
  return card;
}

function renderItems(data) {
  itemList.replaceChildren();
  const sorted = [...data.items].sort((a, b) => {
    if (a.status === "waiting" && b.status !== "waiting") return -1;
    if (a.status !== "waiting" && b.status === "waiting") return 1;
    return b.addedAt - a.addedAt;
  });
  sorted.forEach((item) => itemList.append(makeItemCard(item, data.goal, data.settings)));
  const waitingCount = data.items.filter((item) => item.status === "waiting").length;
  itemCount.textContent = `${waitingCount}개 보류 중`;
  homeWaitingCount.textContent = waitingCount
    ? `${waitingCount}개 상품이 다시 볼 시간을 기다려요`
    : "기다리는 선택을 확인해요";
  emptyState.hidden = data.items.length > 0;
}

function renderGoals(data) {
  goalList.replaceChildren();
  const saved = getSavedAmount(data.items);
  data.goals.forEach((goal) => goalList.append(makeGoalCard(goal, saved, data.activeGoalId)));
  goalCount.textContent = `${data.goals.length}개`;
  goalEmptyState.hidden = data.goals.length > 0;
}

function renderFollowups(data) {
  followupList.replaceChildren();
  const due = data.items.filter((item) =>
    (item.status === "bought" || item.status === "checkout_pending") && item.followupDueAt
      && Date.now() >= item.followupDueAt && !item.regretRecorded
  );
  followupCount.textContent = `${due.length}개`;
  followupEmptyState.hidden = due.length > 0;
  due.forEach((item) => {
    const card = document.createElement("li");
    card.className = "goal-card";
    const title = document.createElement("p");
    title.className = "item-title";
    title.textContent = `${item.title} · ${formatCurrency(item.price)}`;
    const question = document.createElement("p");
    question.className = "goal-card-detail";
    question.textContent = item.status === "checkout_pending"
      ? "결제를 다시 진행한 기록이 있어요. 실제 구매 여부와 사용 경험을 알려주세요."
      : "2주가 지났어요. 아직 잘 사용하고 있나요?";
    const actions = document.createElement("div");
    actions.className = "goal-card-actions";
    if (item.status === "checkout_pending") {
      actions.append(
        makeButton("구매하지 않았어요", "followup-not-bought"),
        makeButton("구매했고 만족해요", "followup-satisfied"),
        makeButton("구매했고 후회돼요", "followup-regret")
      );
    } else {
      actions.append(
        makeButton("네, 잘 써요", "followup-satisfied"),
        makeButton("아니요, 후회돼요", "followup-regret")
      );
    }
    actions.querySelectorAll("button").forEach((button) => {
      button.dataset.itemId = item.id;
    });
    card.append(title, question, actions);
    followupList.append(card);
  });
}

function renderReport(data) {
  const now = new Date();
  const startAt = reportPeriod === "week"
    ? Date.now() - 7 * DAY_IN_MS
    : new Date(now.getFullYear(), now.getMonth(), 1).getTime();
  const events = data.events.filter((event) => event.at >= startAt);
  const temptations = events.filter((event) => event.type === "temptation" || event.type === "checkout_attempt");
  const resisted = events.filter((event) => event.type === "resisted");
  const purchased = events.filter((event) => event.type === "purchase" || event.type === "purchase_intent");
  reportTemptations.textContent = String(temptations.length);
  reportResisted.textContent = String(resisted.length);
  reportPurchased.textContent = String(purchased.length);

  const categoryCounts = new Map();
  temptations.forEach((event) => {
    const category = event.category || "기타";
    categoryCounts.set(category, (categoryCounts.get(category) || 0) + 1);
  });
  const topCategory = [...categoryCounts.entries()].sort((a, b) => b[1] - a[1])[0];
  reportCategory.textContent = topCategory
    ? `${topCategory[0]} · ${topCategory[1]}회`
    : "아직 기록이 없어요.";

  const highRisk = events.filter((event) => Number(event.riskScore) >= 6);
  const hourCounts = Array(24).fill(0);
  highRisk.forEach((event) => {
    const hour = new Date(event.at).getHours();
    if (Number.isInteger(hour) && hour >= 0 && hour < 24) hourCounts[hour] += 1;
  });
  const peakCount = Math.max(...hourCounts);
  const peakHour = hourCounts.indexOf(peakCount);
  const monthEndCount = highRisk.filter((event) => new Date(event.at).getDate() >= 25).length;
  reportTime.textContent = peakCount > 0
    ? `${String(peakHour).padStart(2, "0")}시가 가장 높아요 · ${peakCount}회${monthEndCount ? ` · 월말 ${monthEndCount}회` : ""}`
    : "고위험 응답 기록이 아직 없어요.";
  reportHourChart.replaceChildren();
  reportHourChart.setAttribute(
    "aria-label",
    peakCount > 0
      ? `고위험 응답 시간대 그래프. 가장 높은 시간은 ${peakHour}시, ${peakCount}회입니다.`
      : "고위험 응답 기록이 없습니다. 0시부터 23시까지의 시간대별 그래프입니다."
  );
  hourCounts.forEach((count, hour) => {
    const bar = document.createElement("span");
    bar.className = "hour-chart-bar";
    bar.setAttribute("aria-hidden", "true");
    bar.title = `${String(hour).padStart(2, "0")}시 · ${count}회`;
    bar.style.height = peakCount > 0 ? `${Math.max(4, (count / peakCount) * 100)}%` : "2px";
    if (count > 0 && count === peakCount) bar.classList.add("is-peak");
    reportHourChart.append(bar);
  });

  const recurringAnnual = data.items
    .filter((item) => item.recurring && item.status !== "saved" && item.status !== "not_bought")
    .reduce((sum, item) => sum + annualRecurringCost(item.price, item.cadence), 0);
  reportRecurring.textContent = recurringAnnual
    ? `${formatCurrency(recurringAnnual)} / 년 · 등록된 반복 지출 ${data.items.filter((item) => item.recurring && item.status !== "saved").length}건`
    : "등록된 반복 지출이 없어요.";
}

function renderPurchaseInsight(settings) {
  opportunityAssumptions.textContent = `치킨 ${formatCurrency(settings.chickenPrice)} · 구독 ${formatCurrency(settings.subscriptionPrice)}/월 · 연 7% 복리, 추가 납입 없음`;
  const price = Number(itemPriceInput.value);
  if (!Number.isSafeInteger(price) || price < 1) {
    purchaseInsight.textContent = "가격과 사용 빈도를 입력하면 일하는 시간과 1회 사용 비용을 계산해요.";
    opportunityCopy.textContent = "가격을 입력하면 기회비용을 보여드려요.";
    return;
  }
  const details = [];
  const workTime = formatWorkTime(price, settings.hourlyWage);
  if (workTime) details.push(`내 시급 기준 ${workTime} 일해야 하는 금액`);
  const useCost = getUseCost(
    price,
    Number(usageFrequencyInput.value),
    Number(usageYearsInput.value)
  );
  if (useCost) details.push(`예상 1회 사용 비용 ${formatCurrency(useCost)}`);
  opportunityCopy.textContent = getOpportunityCost(price, settings);
  purchaseInsight.textContent = details.length > 0
    ? details.join(" · ")
    : "주당 사용 횟수와 기간을 입력하면 예상 1회 사용 비용을 계산해요.";
}

async function render() {
  const data = await readData();
  goalNameInput.value = "";
  goalAmountInput.value = "";
  lowRiskDelayInput.value = data.settings.riskDelaySeconds.low;
  mediumRiskDelayInput.value = data.settings.riskDelaySeconds.medium;
  highRiskDelayInput.value = data.settings.riskDelaySeconds.high;
  streakEnabledInput.checked = data.settings.streakEnabled !== false;
  monthlyBudgetInput.value = data.settings.monthlyBudget || "";
  nightModeEnabledInput.checked = Boolean(data.settings.nightModeEnabled);
  nightStartHourInput.value = data.settings.nightStartHour;
  nightEndHourInput.value = data.settings.nightEndHour;
  nightDelayMinutesInput.value = data.settings.nightDelayMinutes;
  nightRequireConfirmationInput.checked = Boolean(data.settings.nightRequireConfirmation);
  personalPledgeInput.value = data.settings.personalPledge || "";
  nightStartHourInput.disabled = !nightModeEnabledInput.checked;
  nightEndHourInput.disabled = !nightModeEnabledInput.checked;
  nightDelayMinutesInput.disabled = !nightModeEnabledInput.checked;
  nightRequireConfirmationInput.disabled = !nightModeEnabledInput.checked;
  renderSummary(data);
  renderStreak(data);
  personalPledgeDisplay.textContent = data.settings.personalPledge
    || "설정에서 나만의 소비 약속을 정해보세요.";
  renderItems(data);
  renderGoals(data);
  renderFollowups(data);
  renderReport(data);
  renderPurchaseInsight(data.settings);
}

document.querySelectorAll("[data-view]").forEach((button) => {
  button.addEventListener("click", () => switchView(button.dataset.view));
});

alertPopupClose.addEventListener("click", closeAlertPopup);
alertPopup.addEventListener("click", (event) => {
  if (event.target === alertPopup) closeAlertPopup();
});
alertPopupCard.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    event.preventDefault();
    closeAlertPopup();
  }
});

document.querySelectorAll("[data-go]").forEach((button) => {
  button.addEventListener("click", () => switchView(button.dataset.go));
});

nightModeEnabledInput.addEventListener("change", () => {
  const enabled = nightModeEnabledInput.checked;
  nightStartHourInput.disabled = !enabled;
  nightEndHourInput.disabled = !enabled;
  nightDelayMinutesInput.disabled = !enabled;
  nightRequireConfirmationInput.disabled = !enabled;
});

for (const input of [itemPriceInput, usageFrequencyInput, usageYearsInput]) {
  input.addEventListener("input", () => {
    readData()
      .then((data) => renderPurchaseInsight(data.settings))
      .catch((error) => {
        console.error("구매 비용 환산 설정을 읽지 못했습니다.", error);
        purchaseInsight.textContent = "비용 환산을 불러오지 못했어요.";
      });
  });
}

itemTitleInput.addEventListener("input", async () => {
  try {
    const data = await readData();
    const similar = hasRegrettedSimilarItem(itemTitleInput.value, data.items);
    regretWarning.hidden = !similar;
    regretWarning.textContent = similar
      ? `지난번 비슷한 물건 “${similar.title}”은(는) 구매 후 후회했다고 기록했어요.`
      : "";
  } catch (error) {
    console.error("비슷한 구매 후회 기록을 확인하지 못했습니다.", error);
    regretWarning.hidden = true;
  }
});

document.querySelectorAll("[data-period]").forEach((button) => {
  button.addEventListener("click", async () => {
    reportPeriod = button.dataset.period;
    document.querySelectorAll("[data-period]").forEach((periodButton) => {
      const selected = periodButton === button;
      periodButton.classList.toggle("is-active", selected);
      periodButton.setAttribute("aria-pressed", String(selected));
    });
    try {
      const data = await readData();
      renderReport(data);
    } catch (error) {
      console.error("소비 패턴 리포트를 불러오지 못했습니다.", error);
      showMessage("리포트를 불러오지 못했습니다.");
    }
  });
});

itemForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const title = itemTitleInput.value.trim();
  const price = Number(itemPriceInput.value);
  const usageFrequency = Number(usageFrequencyInput.value);
  const usageYears = Number(usageYearsInput.value);
  const recurring = itemRecurringInput.checked;
  const category = itemCategoryInput.value === "기타"
    ? inferCategory(title)
    : itemCategoryInput.value;
  if (!title || !Number.isSafeInteger(price) || price < 1) {
    showMessage("상품명과 1원 이상의 가격을 정확히 입력해 주세요.");
    return;
  }
  if ((usageFrequencyInput.value || usageYearsInput.value)
      && (!Number.isFinite(usageFrequency) || usageFrequency < 1
        || !Number.isFinite(usageYears) || usageYears <= 0)) {
    showMessage("사용당 비용을 계산하려면 주당 사용 횟수와 기간을 모두 입력해 주세요.");
    return;
  }

  try {
    const data = await readData();
    const now = Date.now();
    const sourceKey = `manual:${title.toLocaleLowerCase("ko-KR")}`;
    const matching = data.items.find((item) => item.sourceKey === sourceKey && item.status === "waiting");
    const priceHistory = Array.isArray(matching?.priceHistory) ? [...matching.priceHistory] : [];
    if (priceHistory.at(-1)?.price !== price) priceHistory.push({ at: now, price });
    const newItem = {
      ...(matching || {}),
      id: matching?.id || crypto.randomUUID(),
      title,
      price,
      sourceKey,
      category,
      recurring,
      cadence: recurring ? itemCadenceInput.value : "",
      usageFrequency: usageFrequencyInput.value ? usageFrequency : 0,
      usageYears: usageYearsInput.value ? usageYears : 0,
      addedAt: matching?.addedAt || now,
      reviewAt: matching?.reviewAt || now + DAY_IN_MS,
      priceHistory: priceHistory.length ? priceHistory : [{ at: now, price }],
      status: "waiting"
    };
    if (matching) {
      Object.assign(matching, newItem);
    } else {
      data.items.push(newItem);
    }
    data.events.push({
      id: crypto.randomUUID(),
      type: "temptation",
      at: now,
      title,
      price,
      category,
      hour: new Date(now).getHours(),
      dayOfMonth: new Date(now).getDate(),
      riskScore: 0,
      recurring
    });
    await saveData({ items: data.items, activityEvents: data.events });
    itemForm.reset();
    itemCategoryInput.value = "기타";
    itemRecurringInput.checked = false;
    regretWarning.hidden = true;
    showToast("성공적으로 상품 1개를 보류 목록에 담았습니다.", "success");
    await render();
  } catch (error) {
    console.error("보류 상품을 저장하지 못했습니다.", error);
    showMessage("저장하지 못했어요. 브라우저 저장 공간을 확인해 주세요.");
  }
});

settingsForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const riskDelaySeconds = {
    low: Number(lowRiskDelayInput.value),
    medium: Number(mediumRiskDelayInput.value),
    high: Number(highRiskDelayInput.value)
  };
  const monthlyBudget = Number(monthlyBudgetInput.value) || 0;
  const enteredNightStartHour = Number(nightStartHourInput.value);
  const enteredNightEndHour = Number(nightEndHourInput.value);
  const enteredNightDelayMinutes = Number(nightDelayMinutesInput.value);
  const nightStartHour = Number.isInteger(enteredNightStartHour) && enteredNightStartHour >= 0 && enteredNightStartHour <= 23
    ? enteredNightStartHour
    : DEFAULT_DATA.settings.nightStartHour;
  const nightEndHour = Number.isInteger(enteredNightEndHour) && enteredNightEndHour >= 0 && enteredNightEndHour <= 23
    ? enteredNightEndHour
    : DEFAULT_DATA.settings.nightEndHour;
  const nightDelayMinutes = Number.isInteger(enteredNightDelayMinutes) && enteredNightDelayMinutes >= 1 && enteredNightDelayMinutes <= 1440
    ? enteredNightDelayMinutes
    : DEFAULT_DATA.settings.nightDelayMinutes;
  const personalPledge = personalPledgeInput.value.trim();
  if (Object.values(riskDelaySeconds).some((seconds) =>
    !Number.isInteger(seconds) || seconds < 10 || seconds > 86400
  )) {
    showMessage("각 위험도별 대기 시간은 10초부터 86,400초 사이로 입력해 주세요.");
    return;
  }
  if (!Number.isSafeInteger(monthlyBudget) || monthlyBudget < 0) {
    showMessage("월 쇼핑 예산을 확인해 주세요.");
    return;
  }
  if (nightModeEnabledInput.checked
      && (nightStartHour !== enteredNightStartHour
        || nightEndHour !== enteredNightEndHour
        || nightDelayMinutes !== enteredNightDelayMinutes)) {
    showMessage("취약 시간대는 0~23시, 추가 대기는 1~1,440분으로 설정해 주세요.");
    return;
  }

  try {
    const data = await readData();
    await saveData({
      settings: {
        riskDelaySeconds,
        hourlyWage: data.settings.hourlyWage,
        chickenPrice: data.settings.chickenPrice,
        subscriptionPrice: data.settings.subscriptionPrice,
        streakEnabled: streakEnabledInput.checked,
        monthlyBudget,
        nightModeEnabled: nightModeEnabledInput.checked,
        nightStartHour,
        nightEndHour,
        nightDelayMinutes,
        nightRequireConfirmation: nightRequireConfirmationInput.checked,
        personalPledge
      }
    });
    showToast("개입 설정을 저장했습니다.", "success");
    await render();
  } catch (error) {
    console.error("설정을 저장하지 못했습니다.", error);
    showMessage("설정을 저장하지 못했어요. 다시 시도해 주세요.");
  }
});

goalForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const name = goalNameInput.value.trim();
  const amount = Number(goalAmountInput.value) || 0;
  if (amount < 0 || !Number.isSafeInteger(amount)) {
    showMessage("목표 금액은 0 이상의 정수로 입력해 주세요.");
    return;
  }
  if (!name || amount < 1) {
    showMessage("위시리스트 목표 이름과 1원 이상의 금액을 입력해 주세요.");
    return;
  }
  try {
    const data = await readData();
    const goal = { id: crypto.randomUUID(), name, amount, createdAt: Date.now() };
    const goals = [...data.goals, goal];
    await saveData({
      goals,
      activeGoalId: data.activeGoalId || goal.id
    });
    await chrome.storage.local.remove("goal");
    showToast(`위시리스트 목표 “${name}”을 추가했습니다.`, "success");
    await render();
  } catch (error) {
    console.error("절약 목표를 저장하지 못했습니다.", error);
    showMessage("절약 목표를 저장하지 못했습니다. 다시 시도해 주세요.");
  }
});

goalList.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-goal-action]");
  if (!button) return;
  try {
    const data = await readData();
    const goalId = button.dataset.goalId;
    let goals = data.goals;
    let activeGoalId = data.activeGoalId;
    if (button.dataset.goalAction === "delete") {
      goals = goals.filter((goal) => goal.id !== goalId);
      if (activeGoalId === goalId) activeGoalId = goals[0]?.id || "";
    } else {
      activeGoalId = goalId;
    }
    await saveData({ goals, activeGoalId });
    await chrome.storage.local.remove("goal");
    showToast(
      button.dataset.goalAction === "delete" ? "위시리스트 목표를 삭제했습니다." : "홈에 표시할 목표를 변경했습니다.",
      "success"
    );
    await render();
  } catch (error) {
    console.error("위시리스트 목표를 변경하지 못했습니다.", error);
    showMessage("위시리스트 목표를 변경하지 못했습니다.");
  }
});

itemList.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  try {
    const data = await readData();
    const card = button.closest(".item-card");
    const item = data.items.find((entry) => card && card.dataset.itemId === entry.id);
    if (!item) return;
    const action = button.dataset.action;
    if (action === "delete") {
      data.items = data.items.filter((entry) => entry.id !== item.id);
      await saveData({ items: data.items });
      showToast("보류 목록에서 상품 1개를 삭제했습니다.", "success");
    } else {
      if (item.status !== "waiting" || Date.now() < item.reviewAt) return;
      item.status = action === "bought" ? "checkout_pending" : action;
      item.resolvedAt = Date.now();
      item.followupDueAt = action === "bought" ? Date.now() + 14 * DAY_IN_MS : 0;
      data.events.push({
        id: crypto.randomUUID(),
        type: action === "saved" ? "resisted" : "purchase_intent",
        itemId: item.id,
        at: item.resolvedAt,
        title: item.title,
        price: item.price,
        category: item.category || inferCategory(item.title),
        riskScore: item.riskScore || 0,
        recurring: Boolean(item.recurring)
      });
      await saveData({ items: data.items, activityEvents: data.events });
      showToast(
        action === "saved" ? `절약 성공: ${formatCurrency(item.price)}을 지켰어요.` : "구매 결정을 기록했습니다.",
        action === "saved" ? "success" : "info"
      );
    }
    await render();
  } catch (error) {
    console.error("보류 기록을 업데이트하지 못했습니다.", error);
    showMessage("기록을 업데이트하지 못했어요. 다시 시도해 주세요.");
  }
});

followupList.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  try {
    const data = await readData();
    const item = data.items.find((entry) => entry.id === button.dataset.itemId);
    if (!item || !["bought", "checkout_pending"].includes(item.status)
        || Date.now() < item.followupDueAt || item.regretRecorded) return;
    const action = button.dataset.action;
    if (action === "followup-not-bought" && item.status === "checkout_pending") {
      item.status = "not_bought";
      item.regretRecorded = true;
      item.regret = false;
      item.followupOutcome = "not_bought";
    } else if (action === "followup-satisfied") {
      item.status = "bought";
      item.regretRecorded = true;
      item.regret = false;
      item.followupOutcome = "satisfied";
    } else if (action === "followup-regret") {
      item.status = "bought";
      item.regretRecorded = true;
      item.regret = true;
      item.followupOutcome = "regret";
    } else {
      return;
    }
    item.regretAnsweredAt = Date.now();
    data.events.forEach((record) => {
      if (record.itemId !== item.id || record.type !== "purchase_intent") return;
      record.type = item.followupOutcome === "not_bought" ? "purchase_cancelled" : "purchase";
    });
    data.events.push({
      id: crypto.randomUUID(),
      type: item.followupOutcome === "not_bought" ? "resisted" : item.regret ? "regret" : "satisfied",
      at: item.regretAnsweredAt,
      title: item.title,
      category: item.category || inferCategory(item.title),
      price: item.price,
      itemId: item.id
    });
    await saveData({ items: data.items, activityEvents: data.events });
    showToast(
      item.followupOutcome === "not_bought"
        ? "구매하지 않은 것으로 기록했습니다."
        : item.regret ? "후회 기록을 저장했습니다. 비슷한 물건을 담을 때 알려드릴게요." : "사용 만족 기록을 저장했습니다.",
      "success"
    );
    await render();
  } catch (error) {
    console.error("구매 후 사용 기록을 저장하지 못했습니다.", error);
    showMessage("사용 기록을 저장하지 못했습니다.");
  }
});

async function prefillCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const isCartPage = tab?.url && new URL(tab.url).pathname.toLowerCase().includes("cart");
    if (tab && tab.title && !isCartPage && !itemTitleInput.value) {
      itemTitleInput.value = tab.title.slice(0, 120);
    }
  } catch (error) {
    console.error("현재 탭의 제목을 가져오지 못했습니다.", error);
  }
}

render().catch((error) => {
  console.error("앱 데이터를 불러오지 못했습니다.", error);
  showMessage("저장된 정보를 불러오지 못했어요. 확장 프로그램을 다시 열어 주세요.");
});
prefillCurrentTab();

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local" || !changes.items) return;
  const previous = Array.isArray(changes.items.oldValue) ? changes.items.oldValue : [];
  const current = Array.isArray(changes.items.newValue) ? changes.items.newValue : [];
  const addedCount = Math.max(0, current.length - previous.length);
  if (addedCount > 0) showToast(`성공적으로 ${addedCount}개의 상품을 보류 목록에 담았습니다.`, "success");
  render().catch((error) => {
    console.error("변경된 보류 목록을 표시하지 못했습니다.", error);
    showToast("보류 목록을 새로 고치지 못했습니다.", "error");
  });
});
